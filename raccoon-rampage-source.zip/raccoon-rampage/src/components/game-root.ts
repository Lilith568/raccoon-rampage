import { createComponent } from '@iwsdk/core';

/** Tags the entity that owns the procedurally built campsite and game objects. */
export const RaccoonGame = createComponent('RaccoonGame', {});
