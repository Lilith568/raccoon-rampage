/**
 * Raccoon Rampage: a WebXR arcade game built with Meta's Immersive Web SDK.
 * You are a raccoon at a pop-up comic campsite. Throw snacks at campers, duck their
 * flashlights and defeat Ranger Rick.
 */
import { World } from '@iwsdk/core';
import projectOptions from 'virtual:iwsdk-project';
import comicFont from '@fontsource/bangers/files/bangers-latin-400-normal.woff2?url';
import { loadComicFont } from './art/ink.js';
import { GameSystem } from './game/game-system.js';

// the comic font must be ready before any lettering is drawn onto textures
loadComicFont(comicFont).then(() => World.create(document.getElementById('scene-container') as HTMLDivElement, projectOptions)).then((world) => {
  world.registerSystem(GameSystem);
  (window as unknown as { __rr: unknown }).__rr = { world };
});
