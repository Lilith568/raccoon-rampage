import { defineComponents } from '@iwsdk/core';
import { RaccoonGame } from './components/game-root.js';

export default defineComponents([RaccoonGame]);
