/**
 * The campsite as a pop-up comic book: hand-drawn cut-out trees, tents and props stand in
 * layers around the player, who stays behind a 3D picnic table and looks down the clearing (−Z).
 */
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import {
  BackSide, BoxGeometry, BufferGeometry, CanvasTexture, CircleGeometry, CylinderGeometry, DirectionalLight, Fog, Group, HemisphereLight, Material, Mesh,
  MeshBasicMaterial, MeshToonMaterial, Object3D, PointLight, RepeatWrapping, Scene, Sprite, SpriteMaterial,
} from '@iwsdk/core';
import { blob, canvas, card, circle, Ctx, curve, cutMat, ellipse, fill, halftone, ink, INK, line, mix, nightShade, poly, rng, rrect, shadeColor, tex, within, cardGeo } from '../art/ink.js';
import { glow } from '../art/props.js';

export const TABLE = { z: -0.62, top: 0.86, width: 1.6, depth: 0.72 };
export const STASH = { x: 0.95, y: 0.95, z: -0.55 };

export function seeded(seed: number): () => number { return rng(seed); }

export interface Camp {
  root: Group;
  fire: { flames: Object3D[]; light: PointLight; glow: Sprite };
  stash: Group;
  tray: Group;
  clouds: Object3D[];
}

// ---------- drawings ----------
function drawPine(g: Ctx, v: number): void {
  const r = rng(v * 31 + 7);
  const greens = [['#2f7a4f', '#1f4f45', '#56b07a'], ['#2a6b52', '#1a4448', '#4fa37c'], ['#3b7d3f', '#234b3b', '#6bbf6a']][v % 3];
  ink(g, rrect(112, 420, 32, 90, 6), '#6b4426', 8);
  const tiers = 4; const w0 = v === 1 ? 120 : 100;
  for (let i = 0; i < tiers; i++) {
    const top = 20 + i * 92; const bot = top + 170; const w = 30 + (i + 1) * (w0 / tiers) * 0.95;
    const pts = [128, top];
    const n = 5;
    for (let k = 0; k <= n; k++) { const x = 128 + w - (2 * w * k) / n; pts.push(x, bot + (k % 2 ? -14 : 6) + (r() - 0.5) * 8); }
    const p = blob(pts, 0.35);
    ink(g, p, greens[0], 9);
    within(g, p, () => { fill(g, poly([128, top - 10, 128 - w - 20, bot + 30, 40, bot + 30]), greens[1]); line(g, curve([150, top + 40, 170, top + 90, 200, bot - 10]), 6, greens[2]); });
  }
  halftone(g, poly([0, 0, 128, 0, 128, 512, 0, 512]), 128, 260, 20, 260, shadeColor(greens[1], -0.3), 12);
}

function drawBush(g: Ctx): void {
  const p = blob([20, 150, 30, 90, 80, 50, 140, 40, 200, 60, 240, 110, 236, 150]); ink(g, p, '#2f7a4f', 9);
  within(g, p, () => { fill(g, ellipse(60, 150, 80, 60), '#1f4f45'); for (const [x, y] of [[90, 80], [160, 70], [200, 110]]) line(g, curve([x - 14, y + 6, x, y - 4, x + 14, y + 6]), 5, '#56b07a'); });
  for (const [x, y] of [[120, 100], [180, 120], [70, 120]]) ink(g, circle(x, y, 8), '#ff4d6d', 4);
}

function drawTent(g: Ctx, col: string): void {
  const sh = nightShade(col);
  const body = poly([256, 40, 490, 400, 22, 400]); ink(g, body, col, 12);
  within(g, body, () => {
    fill(g, poly([256, 40, 22, 400, 140, 400]), sh);
    for (let y = 80; y < 400; y += 70) fill(g, poly([256, y - 6, 256 + (y / 400) * 240, y + 30, 256 + (y / 400) * 240, y + 44, 256, y + 8]), shadeColor(col, 0.35));
  });
  halftone(g, body, 256, 220, 60, 400, shadeColor(sh, -0.25), 14);
  // open door with a warm lantern glow inside
  const door = poly([256, 150, 350, 400, 162, 400]); ink(g, door, '#2a1c14', 8);
  within(g, door, () => { const gr = g.createRadialGradient(256, 360, 4, 256, 360, 130); gr.addColorStop(0, '#ffd27a'); gr.addColorStop(1, '#2a1c1400'); g.fillStyle = gr; g.fillRect(150, 150, 220, 260); });
  ink(g, poly([256, 150, 330, 400, 300, 400, 256, 200]), shadeColor(col, -0.1), 7); // flap
  line(g, curve([256, 40, 256, 24, 250, 10]), 10); line(g, curve([256, 40, 270, 22, 284, 12]), 10);
  // ropes and pegs
  line(g, curve([40, 380, 10, 410, 4, 418]), 4, '#e9e2cf'); line(g, curve([472, 380, 500, 410, 508, 418]), 4, '#e9e2cf');
}

function drawFireBase(g: Ctx): void {
  for (const [a, b, c2] of [[60, 280, 0.4], [-40, 196, -0.4]] as const) { g.save(); g.translate(256, 200); g.rotate(c2); ink(g, rrect(-a - 170, -26, 340, 52, 24), '#6b4426', 9); fill(g, rrect(-a - 170, 2, 340, 18, 0), '#4a2f1a'); ink(g, ellipse(-a + 170, 0, 20, 26), '#c99a6b', 6); g.restore(); void b; }
  const r = rng(5);
  for (let i = 0; i < 9; i++) { const x = 40 + i * 54; const y = 222 + Math.sin(i) * 8; const s = blob([x - 30, y, x - 20, y - 26, x + 10, y - 30, x + 30, y - 6, x + 22, y + 22, x - 20, y + 22]); ink(g, s, '#8e8a96', 8); within(g, s, () => fill(g, ellipse(x - 20, y + 10, 30, 22), '#5d5a78')); void r; }
}

function drawFlame(g: Ctx, v: number): void {
  const wob = [[0, 0, 0], [12, -10, 8], [-10, 8, -6]][v];
  const outer = blob([128, 10 + wob[0], 170, 110, 214, 70 + wob[1], 220, 220, 196, 330, 128, 370, 60, 330, 36, 220, 46, 80 + wob[2], 92, 120]);
  ink(g, outer, '#ff7b1c', 9);
  ink(g, blob([128, 90 + wob[1], 166, 190, 172, 290, 128, 350, 84, 290, 92, 200]), '#ffd23f', 0.1);
  fill(g, blob([128, 200, 150, 270, 128, 340, 106, 270]), '#fff7d6');
}

function drawLog(g: Ctx): void {
  const l = rrect(20, 30, 470, 100, 46); ink(g, l, '#7a4e2d', 10);
  within(g, l, () => { fill(g, rrect(20, 90, 470, 50, 0), '#5a3a22'); for (let x = 70; x < 430; x += 60) line(g, curve([x, 46, x + 20, 70, x + 6, 100]), 5, '#4a2f1a'); });
  ink(g, ellipse(470, 80, 38, 50), '#d9a066', 9); line(g, ellipse(470, 80, 20, 28), 5, '#a0663a');
}

function drawLantern(g: Ctx): void {
  ink(g, rrect(40, 140, 16, 240, 6), '#4a2f1a', 6);
  line(g, curve([48, 144, 48, 110, 30, 96]), 6);
  ink(g, rrect(6, 40, 52, 70, 10), '#ffd27a', 7);
  within(g, rrect(6, 40, 52, 70, 10), () => fill(g, circle(32, 75, 18), '#fff7d6'));
  ink(g, rrect(2, 30, 60, 14, 4), '#2b2d42', 5); ink(g, rrect(2, 106, 60, 12, 4), '#2b2d42', 5);
}

function drawMoon(g: Ctx): void {
  const m = circle(256, 256, 220); ink(g, m, '#fff2b3', 14);
  within(g, m, () => { fill(g, circle(120, 300, 220), '#f2d98a'); for (const [x, y, rr] of [[330, 140, 34], [170, 180, 22], [360, 360, 26], [220, 400, 18]]) { ink(g, circle(x, y, rr), '#e8cf80', 5); } });
  halftone(g, m, 330, 240, 80, 320, '#d9bf6e', 16);
  // a sleepy, smug moon face
  line(g, curve([250, 236, 280, 252, 310, 236]), 10); line(g, curve([350, 230, 378, 246, 404, 230]), 10);
  line(g, curve([300, 316, 340, 340, 384, 312]), 10);
  g.save(); g.globalAlpha = 0.5; fill(g, ellipse(260, 290, 30, 16), '#ff9fb0'); fill(g, ellipse(410, 286, 22, 14), '#ff9fb0'); g.restore();
}

function drawCloud(g: Ctx, v: number): void {
  const pts = v ? [30, 170, 40, 110, 110, 80, 170, 40, 260, 50, 320, 90, 400, 80, 470, 130, 480, 180] : [20, 180, 50, 120, 120, 100, 200, 50, 300, 70, 380, 60, 450, 110, 490, 180];
  const p = blob(pts); ink(g, p, '#4a4f8f', 9);
  within(g, p, () => { fill(g, ellipse(260, 70, 220, 40), '#7d84c7'); fill(g, ellipse(260, 200, 260, 40), '#353a73'); });
}

function drawStar(g: Ctx): void {
  fill(g, poly([32, 0, 38, 26, 64, 32, 38, 38, 32, 64, 26, 38, 0, 32, 26, 26]), '#fff7d6');
}

function tile(draw: (g: Ctx) => void, size = 256): CanvasTexture {
  const [c, g] = canvas(size, size); draw(g); const t = tex(c); t.wrapS = RepeatWrapping; t.wrapT = RepeatWrapping; return t;
}
function drawGrass(g: Ctx): void {
  g.fillStyle = '#2c5a42'; g.fillRect(0, 0, 256, 256);
  const r = rng(3);
  for (let i = 0; i < 46; i++) { const x = r() * 256; const y = r() * 256; line(g, curve([x - 8, y, x - 4, y - 10, x, y]), 4, '#204535'); line(g, curve([x, y, x + 4, y - 12, x + 8, y]), 4, '#3d7656'); }
  for (let i = 0; i < 5; i++) fill(g, circle(r() * 256, r() * 256, 4), '#ffd23f');
}
function drawDirt(g: Ctx): void {
  g.fillStyle = '#6e5038'; g.fillRect(0, 0, 256, 256);
  const r = rng(9);
  for (let i = 0; i < 30; i++) { const x = r() * 256; const y = r() * 256; line(g, curve([x - 10, y, x, y + 2, x + 10, y]), 4, '#5a3f2b'); }
  for (let i = 0; i < 9; i++) { const x = 20 + r() * 216; const y = 20 + r() * 216; ink(g, ellipse(x, y, 6 + r() * 4, 4 + r() * 3), '#9a8f86', 3); }
}
function drawCloth(g: Ctx): void {
  const S = 512; g.fillStyle = '#ffffff'; g.fillRect(0, 0, S, S);
  const n = 8; const w = S / n;
  for (let i = 0; i < n; i++) { if (i % 2 === 0) { g.fillStyle = '#e63946cc'; g.fillRect(i * w, 0, w, S); g.fillRect(0, i * w, S, w); } }
  for (let i = 0; i < n; i += 2) for (let j = 0; j < n; j += 2) { g.fillStyle = '#b3172b'; g.fillRect(i * w, j * w, w, w); }
  g.lineWidth = 3; g.strokeStyle = '#00000022'; for (let k = 0; k < 6; k++) { g.beginPath(); g.moveTo(0, 60 + k * 80); g.bezierCurveTo(180, 40 + k * 80, 330, 90 + k * 80, 512, 60 + k * 80); g.stroke(); }
  g.lineWidth = 12; g.strokeStyle = INK; g.strokeRect(0, 0, S, S);
}
function drawWicker(g: Ctx): void {
  g.fillStyle = '#b07a43'; g.fillRect(0, 0, 256, 128);
  for (let y = 0; y < 128; y += 16) for (let x = (y / 16) % 2 ? 0 : 16; x < 256; x += 32) { ink(g, rrect(x + 2, y + 2, 28, 12, 6), '#c98f55', 2); }
}

// ---------- build ----------
export function buildCamp(scene: Scene): Camp {
  scene.fog = new Fog('#2a2850', 22, 75);
  const root = new Group(); root.name = 'Campsite';
  const r = rng(42);
  // the 3D bits (table, basket, paws) get toon lighting
  root.add(new HemisphereLight('#8f9bff', '#2a2420', 1.1));
  const moonLight = new DirectionalLight('#dfe4ff', 1.2); moonLight.position.set(-6, 10, 4); root.add(moonLight);

  const mk = (w: number, h: number, f: (g: Ctx) => void) => { const [c, g] = canvas(w, h); f(g); return tex(c); };
  const T = {
    pine: [0, 1, 2].map((v) => mk(256, 512, (g) => drawPine(g, v))), bush: mk(256, 180, drawBush),
    tent: ['#e63946', '#ffb703', '#2ec4b6', '#3a86ff'].map((c2) => mk(512, 420, (g) => drawTent(g, c2))),
    base: mk(512, 280, drawFireBase), flame: [0, 1, 2].map((v) => mk(256, 384, (g) => drawFlame(g, v))), log: mk(512, 160, drawLog),
    lantern: mk(64, 384, drawLantern), moon: mk(512, 512, drawMoon), cloud: [0, 1].map((v) => mk(512, 230, (g) => drawCloud(g, v))), star: mk(64, 64, drawStar),
  };
  const faceOrigin = (o: Object3D) => { o.rotation.y = Math.atan2(-o.position.x, -o.position.z + 0.0001); };

  // sky: smug moon, comic clouds and sparkly stars (not fogged)
  const moon = card(T.moon, 12, 12, 0.5, 0.5); (moon.material as MeshBasicMaterial).fog = false; moon.position.set(-16, 20, -58); faceOrigin(moon); root.add(moon);
  const clouds: Object3D[] = [];
  for (let i = 0; i < 5; i++) { const c2 = card(T.cloud[i % 2], 13 + r() * 6, 5.5, 0.5, 0.5); (c2.material as MeshBasicMaterial).fog = false; const a = -2.4 + i * 0.55; c2.position.set(Math.sin(a) * 62, 30 + r() * 10, -Math.abs(Math.cos(a)) * 62 - 10); faceOrigin(c2); root.add(c2); clouds.push(c2); }
  const starMat = new SpriteMaterial({ map: T.star, alphaTest: 0.4, fog: false, toneMapped: false });
  for (let i = 0; i < 140; i++) { const s = new Sprite(starMat); const a = r() * Math.PI * 2; const e = 0.2 + r() * 1.2; const d = 90; s.position.set(Math.cos(a) * Math.cos(e) * d, Math.sin(e) * d, Math.sin(a) * Math.cos(e) * d); const k = 0.8 + r() * 1.6; s.scale.set(k, k, 1); root.add(s); }

  // ground: drawn grass with a trodden dirt clearing
  const grassT = tile(drawGrass); grassT.repeat.set(40, 40);
  const grass = new Mesh(new CircleGeometry(90, 48), new MeshBasicMaterial({ map: grassT, color: '#a9b0d8', toneMapped: false })); grass.rotation.x = -Math.PI / 2; root.add(grass);
  const dirtT = tile(drawDirt); dirtT.repeat.set(18, 18);
  const clearing = new Mesh(new CircleGeometry(14, 48), new MeshBasicMaterial({ map: dirtT, color: '#b4accd', toneMapped: false })); clearing.rotation.x = -Math.PI / 2; clearing.position.set(0, 0.01, -11); clearing.scale.set(1.3, 1, 1); root.add(clearing);
  const [rc, rg] = canvas(512, 512); { const p = ellipse(256, 256, 250, 250); rg.lineWidth = 14; rg.strokeStyle = INK; rg.stroke(p); }
  const rim = new Mesh(new CircleGeometry(14, 48), new MeshBasicMaterial({ map: tex(rc), transparent: true, depthWrite: false, toneMapped: false })); rim.rotation.x = -Math.PI / 2; rim.position.set(0, 0.015, -11); rim.scale.set(1.3, 1, 1); root.add(rim);

  // trees in pop-up rows: further rows get bluer and darker (atmospheric comic depth)
  const rows: [number, number, string, number][] = [[19, 34, '#c4cbef', 7], [25, 40, '#a2abdd', 6.2], [33, 52, '#808ac6', 5.4], [44, 64, '#636caf', 4.8]];
  const staticCards: Mesh[] = [];
  for (const [dist, count, tint, h] of rows) {
    for (let i = 0; i < count; i++) {
      const a = -Math.PI * 1.04 + (i + r() * 0.7) / count * Math.PI * 1.08; // semicircle in front of the player
      const d = dist + (r() - 0.5) * 4; const x = Math.cos(a) * d * 1.05; const z = Math.sin(a) * d - 4;
      if (z > 2) continue;
      const hh = h * (0.8 + r() * 0.5);
      const t = card(T.pine[i % 3], hh * 0.5, hh, 0.5, 0, tint); t.position.set(x, 0, z); faceOrigin(t); staticCards.push(t);
    }
  }
  for (let i = 0; i < 22; i++) { const side = i % 2 ? 1 : -1; const hh = 5 + r() * 3; const t = card(T.pine[i % 3], hh * 0.5, hh, 0.5, 0, '#cdd3f2'); t.position.set(side * (8 + r() * 9), 0, 4 - r() * 12); faceOrigin(t); staticCards.push(t); }
  for (let i = 0; i < 16; i++) { const a = -2.6 + i * 0.33; const d = 15 + r() * 3; const b = card(T.bush, 1.8, 1.25, 0.5, 0, '#c9cff0'); b.position.set(Math.sin(a) * d, 0, -Math.abs(Math.cos(a)) * d - 3); faceOrigin(b); staticCards.push(b); }
  // tents, log benches and lanterns around the fire
  [[-8, -15], [7.5, -16.5], [-11.5, -8.5], [11.5, -9.5]].forEach(([x, z], i) => { const t = card(T.tent[i], 4.2, 3.45, 0.5, 0, '#dcdff5'); t.position.set(x, 0, z); faceOrigin(t); staticCards.push(t); });
  [[-2.8, -10], [2.9, -12.4]].forEach(([x, z]) => { const l = card(T.log, 2.4, 0.75, 0.5, 0, '#e2e2f4'); l.position.set(x, 0, z); faceOrigin(l); staticCards.push(l); });
  const lampGlows: Sprite[] = [];
  [[-5, -6], [5.5, -6.5], [-4, -17], [4.5, -18]].forEach(([x, z]) => { const l = card(T.lantern, 0.3, 1.8, 0.5, 0); l.position.set(x, 0, z); faceOrigin(l); staticCards.push(l); const gl = glow('#ffd27a', 1.6, 0.55); gl.position.set(x, 1.55, z); root.add(gl); lampGlows.push(gl); });
  for (const s of staticCards) root.add(s);
  bakeCards(root, staticCards);

  // campfire: drawn base, three flickering flame cards and a warm glow
  const fireGroup = new Group(); fireGroup.position.set(0, 0, -11);
  const base = card(T.base, 2.6, 1.42, 0.5, 0.18); fireGroup.add(base);
  const flames: Object3D[] = [];
  for (let i = 0; i < 3; i++) { const f = card(T.flame[i], 1.2 - i * 0.25, 1.8 - i * 0.35, 0.5, 0); f.position.set((i - 1) * 0.28, 0.12, 0.02 + i * 0.01); (f.material as MeshBasicMaterial).fog = false; fireGroup.add(f); flames.push(f); }
  faceOrigin(fireGroup);
  const fireGlow = glow('#ff9a3c', 7, 0.55); fireGlow.position.set(0, 1.0, -10.9); root.add(fireGlow);
  const fireLight = new PointLight('#ff9a3c', 10, 18, 1.6); fireLight.position.set(0, 1.2, -11); root.add(fireLight);
  root.add(fireGroup);

  // the raccoon's picnic table (3D, toon-shaded with ink outlines and a gingham cloth)
  const table = new Group(); table.position.set(0, 0, TABLE.z);
  const toon = (c2: string) => new MeshToonMaterial({ color: c2 });
  const outline = new MeshBasicMaterial({ color: INK, side: BackSide });
  const addOutlined = (geo: BufferGeometry, mat: Material | Material[], x: number, y: number, z: number, grow = 0.025) => {
    const m = new Mesh(geo, mat); m.position.set(x, y, z); table.add(m);
    const o = new Mesh(geo, outline); o.position.set(x, y, z); geo.computeBoundingBox(); const bb = geo.boundingBox!;
    o.scale.set(1 + grow / (bb.max.x - bb.min.x), 1 + grow / (bb.max.y - bb.min.y), 1 + grow / (bb.max.z - bb.min.z)); table.add(o);
    return m;
  };
  const clothT = (() => { const [c2, g] = canvas(512, 512); drawCloth(g); return tex(c2); })();
  const wood = toon('#9a6a3e');
  const clothMat = new MeshBasicMaterial({ map: clothT, toneMapped: false });
  addOutlined(new BoxGeometry(TABLE.width + 0.6, 0.07, TABLE.depth), [wood, wood, clothMat, wood, wood, wood], 0, TABLE.top - 0.035, 0, 0.03);
  for (const sx of [-1, 1]) addOutlined(new BoxGeometry(0.08, TABLE.top - 0.07, 0.08), toon('#6b4426'), sx * (TABLE.width / 2 + 0.15), (TABLE.top - 0.07) / 2, 0, 0.03);
  addOutlined(new BoxGeometry(TABLE.width + 0.4, 0.05, 0.1), toon('#6b4426'), 0, 0.42, TABLE.depth / 2 - 0.05, 0.03);
  root.add(table);
  const tray = new Group(); tray.position.set(-0.15, TABLE.top + 0.01, TABLE.z); root.add(tray);
  // snack stash: a woven basket
  const stash = new Group(); stash.position.set(STASH.x, TABLE.top, STASH.z);
  const wickT = (() => { const [c2, g] = canvas(256, 128); drawWicker(g); const t = tex(c2); t.wrapS = RepeatWrapping; t.repeat.set(3, 1); return t; })();
  const basketGeo = new CylinderGeometry(0.23, 0.18, 0.22, 20, 1, true);
  const basket = new Mesh(basketGeo, new MeshBasicMaterial({ map: wickT, side: 2, toneMapped: false })); basket.position.y = 0.11; stash.add(basket);
  const bo = new Mesh(basketGeo, outline); bo.position.y = 0.11; bo.scale.set(1.08, 1.04, 1.08); stash.add(bo);
  const bottom = new Mesh(new CircleGeometry(0.18, 20), new MeshBasicMaterial({ color: '#5a3a22' })); bottom.rotation.x = -Math.PI / 2; bottom.position.y = 0.01; stash.add(bottom);
  root.add(stash);

  void mix; void cutMat; void cardGeo; void lampGlows;
  return { root, fire: { flames, light: fireLight, glow: fireGlow }, stash, tray, clouds };
}

/** Merges the static cut-outs into one mesh per material: the whole backdrop costs a handful of draw calls. */
function bakeCards(root: Group, cards: Mesh[]): void {
  root.updateMatrixWorld(true);
  const byMat = new Map<string, { mat: MeshBasicMaterial; geos: BufferGeometry[] }>();
  for (const m of cards) {
    const mat = m.material as MeshBasicMaterial; const key = `${mat.map?.uuid}|${mat.color.getHexString()}`;
    const g = m.geometry.clone(); g.applyMatrix4(m.matrixWorld);
    let e = byMat.get(key); if (!e) { e = { mat, geos: [] }; byMat.set(key, e); }
    e.geos.push(g); root.remove(m);
  }
  for (const { mat, geos } of byMat.values()) {
    const merged = mergeGeometries(geos, false); if (!merged) continue;
    const mesh = new Mesh(merged, mat); mesh.name = 'backdrop'; mesh.matrixAutoUpdate = false; root.add(mesh);
  }
}
