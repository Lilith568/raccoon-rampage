/**
 * Raccoon Rampage builds all of its content procedurally (see src/world/*),
 * so the shared asset manifest is intentionally empty.
 */
import { defineAssets } from '@iwsdk/core';

export default defineAssets({});
