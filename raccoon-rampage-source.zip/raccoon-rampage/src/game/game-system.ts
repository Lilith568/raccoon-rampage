/**
 * Raccoon Rampage game loop: grab snacks-as-ammo from the picnic table, throw them at
 * campers to make them drop their snacks, duck flashlight beams, and beat Ranger Rick.
 */
import {
  createSystem, Group, Object3D, Sprite, SpriteMaterial, Vector3, VisibilityState,
} from '@iwsdk/core';
import { RaccoonGame } from '../components/game-root.js';
import { buildCamper, CamperRig, heldSnack } from '../art/campers.js';
import { AMMO_KINDS, AmmoKind, buildAmmo, buildNet, buildPaw, buildSnackSprite } from '../art/props.js';
import { buildRanger, RangerRig } from '../art/ranger.js';
import { buildCamp, Camp, STASH, TABLE } from '../world/camp.js';
import { Fx } from './fx.js';
import { Hud } from './hud.js';
import { Sfx } from './sfx.js';

const G = 9.81;
const RS = 1.25; // Ranger Rick puppet scale
const HANDS = ['left', 'right'] as const;
type Hand = (typeof HANDS)[number];
type Phase = 'intro' | 'wave' | 'break' | 'boss' | 'victory' | 'gameover';

interface WaveDef { name: string; dur: number; every: number; max: number; kid: number; flash: number; speed: [number, number]; hint: string; }
const WAVES: WaveDef[] = [
  { name: 'WAVE 1', dur: 45, every: 2.4, max: 5, kid: 0, flash: 0, speed: [1.0, 1.35], hint: 'Throw at campers to make them drop their snacks. Quick hits build a combo!' },
  { name: 'WAVE 2', dur: 45, every: 1.5, max: 8, kid: 0.4, flash: 0, speed: [1.4, 2.1], hint: 'Rush hour! Kids are fast and worth double.' },
  { name: 'WAVE 3', dur: 50, every: 2.0, max: 7, kid: 0.2, flash: 0.5, speed: [1.1, 1.6], hint: 'Flashlights! When a beam swings your way: DUCK for real.' },
];
const WAVE_TITLES = ['SNACK THIEVES', 'RUSH HOUR', 'FLASHLIGHTS'];

interface Camper { rig: CamperRig; seed: number; x: number; z: number; dir: number; speed: number; state: 'walk' | 'hit' | 'flee' | 'scan' | 'idle'; t: number; snack: Object3D | null; kid: boolean; scanCooldown: number; warned: boolean; alive: boolean; tutorial: boolean; }
interface Projectile { mesh: Sprite; vel: Vector3; age: number; bounced: boolean; alive: boolean; }
interface FlyingSnack { mesh: Sprite; from: Vector3; age: number; dur: number; value: number; alive: boolean; }
interface TraySlot { kind: AmmoKind; mesh: Sprite; home: Vector3; taken: boolean; respawn: number; }
interface Net { obj: Sprite; vel: Vector3; age: number; alive: boolean; }

export class GameSystem extends createSystem({ game: { required: [RaccoonGame] } }) {
  private camp!: Camp;
  private root!: Group;
  private hud!: Hud;
  private sfx = new Sfx();
  private phase: Phase = 'intro';
  private phaseTime = 0;
  private waveIdx = 0;
  private spawnTimer = 0;
  private score = 0;
  private snacks = 0;
  private combo = 1;
  private lastHit = -10;
  private now = 0;
  private stunnedUntil = 0;
  private seed = 1;
  private campers: Camper[] = [];
  private projectiles: Projectile[] = [];
  private flying: FlyingSnack[] = [];
  private rain: { mesh: Sprite; vel: Vector3; spin: number; delay: number; landed: boolean }[] = [];
  private fx = new Fx();
  private hatPop = 0;
  private ouch = 0;
  private nets: Net[] = [];
  private tray: TraySlot[] = [];
  private held: Record<Hand, TraySlot | null> = { left: null, right: null };
  private heldButton: Record<Hand, number> = { left: -1, right: -1 };
  private gripHist: Record<Hand, { p: Vector3[]; t: number[]; i: number }> = { left: { p: [], t: [], i: 0 }, right: { p: [], t: [], i: 0 } };
  private paws: Record<Hand, Group | null> = { left: null, right: null };
  private ranger: RangerRig | null = null;
  private boss = { hp: 1, maxHp: 14, x: 0, dir: 1, attackT: 2.5, lightT: 6, sweeping: 0, flash: 0, defeated: 0 };
  private standHeight = 1.5;
  private duckKey = false;
  private mouse = { x: 0, y: 0, clicked: false, down: false };
  private crosshair: HTMLDivElement | null = null;
  private help: HTMLDivElement | null = null;
  private best = 0;
  private hudTimer = 0;
  // scratch
  private v1 = new Vector3(); private v2 = new Vector3(); private v3 = new Vector3(); private head = new Vector3(); private grip = new Vector3();
  private stashPos = new Vector3(STASH.x, STASH.y + 0.1, STASH.z);

  init(): void {
    this.root = new Group(); this.root.name = 'RaccoonRampage';
    const entity = this.world.createTransformEntity(this.root);
    entity.addComponent(RaccoonGame);
    this.camp = buildCamp(this.scene);
    this.root.add(this.camp.root);
    this.hud = new Hud(); this.root.add(this.hud.board); this.root.add(this.hud.banner); this.root.add(this.fx.root);
    this.buildTray();
    try { this.best = Number(localStorage.getItem('raccoon-rampage.best') || 0); } catch { this.best = 0; }
    for (const hand of HANDS) {
      const paw = buildPaw(); paw.name = `Paw-${hand}`;
      const space = this.player.gripSpaces[hand];
      if (space) { space.add(paw); this.paws[hand] = paw; }
      for (let k = 0; k < 6; k++) { this.gripHist[hand].p.push(new Vector3()); this.gripHist[hand].t.push(0); }
    }
    this.setupDesktopInput();
    this.enterIntro();
    (window as unknown as { __rrGame: unknown }).__rrGame = this; // handle for automated playtests
    this.cleanupFuncs.push(this.visibilityState.subscribe((v) => {
      const flat = v === VisibilityState.NonImmersive;
      if (this.crosshair) this.crosshair.style.display = flat ? 'block' : 'none';
      if (this.help) this.help.style.display = flat ? 'block' : 'none';
      if (!flat) this.sfx.unlock();
    }));
  }

  // ---------- setup ----------
  private buildTray(): void {
    const cols = 6;
    for (let i = 0; i < 12; i++) {
      const kind = AMMO_KINDS[i % AMMO_KINDS.length];
      const mesh = buildAmmo(kind);
      const home = new Vector3(-0.55 + (i % cols) * 0.2, 0.06, (i < cols ? -0.12 : 0.1));
      mesh.position.copy(home); this.camp.tray.add(mesh);
      this.tray.push({ kind, mesh, home, taken: false, respawn: 0 });
    }
  }

  private setupDesktopInput(): void {
    const canvas = this.renderer.domElement;
    const ch = document.createElement('div');
    ch.style.cssText = 'position:fixed;left:50%;top:50%;width:26px;height:26px;margin:-13px 0 0 -13px;border:3px solid rgba(255,230,160,.9);border-radius:50%;pointer-events:none;z-index:5;box-shadow:0 0 8px rgba(0,0,0,.6)';
    document.body.appendChild(ch); this.crosshair = ch;
    const help = document.createElement('div');
    help.style.cssText = 'position:fixed;left:16px;bottom:14px;color:#f2cc8f;font:600 14px system-ui,sans-serif;background:rgba(20,14,8,.72);padding:8px 12px;border-radius:10px;z-index:5;pointer-events:none';
    help.textContent = 'Mouse: aim · Click: throw · Hold C: duck · Enter VR for the full raccoon experience';
    document.body.appendChild(help); this.help = help;
    const move = (e: PointerEvent) => {
      const r = canvas.getBoundingClientRect();
      this.mouse.x = ((e.clientX - r.left) / r.width) * 2 - 1; this.mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1;
      ch.style.left = `${e.clientX}px`; ch.style.top = `${e.clientY}px`; ch.style.margin = '-13px 0 0 -13px';
    };
    const down = (e: PointerEvent) => { move(e); this.mouse.clicked = true; this.sfx.unlock(); };
    const key = (e: KeyboardEvent, on: boolean) => { if (e.code === 'KeyC' || e.code === 'ControlLeft' || e.code === 'KeyS') this.duckKey = on; if (on && (e.code === 'Enter' || e.code === 'Space')) { this.mouse.clicked = true; this.sfx.unlock(); } };
    const kd = (e: KeyboardEvent) => key(e, true); const ku = (e: KeyboardEvent) => key(e, false);
    canvas.addEventListener('pointermove', move); canvas.addEventListener('pointerdown', down);
    window.addEventListener('keydown', kd); window.addEventListener('keyup', ku);
    this.cleanupFuncs.push(() => { canvas.removeEventListener('pointermove', move); canvas.removeEventListener('pointerdown', down); window.removeEventListener('keydown', kd); window.removeEventListener('keyup', ku); ch.remove(); help.remove(); });
  }

  // ---------- phases ----------
  private enterIntro(): void {
    this.phase = 'intro'; this.phaseTime = 0; this.clearActors();
    this.score = 0; this.snacks = 0; this.combo = 1; this.waveIdx = 0;
    const ted = this.spawnCamper({ x: 0.8, z: -6, tutorial: true });
    ted.state = 'idle'; ted.rig.root.rotation.y = 0;
    this.hud.show('RACCOON RAMPAGE', this.now, 3.5, '#ffd166');
  }

  private startWave(i: number): void {
    this.phase = 'wave'; this.phaseTime = 0; this.waveIdx = i; this.spawnTimer = 0.5;
    this.hud.show(`${WAVES[i].name}: ${WAVE_TITLES[i]}`, this.now, 2.6); this.sfx.wave();
  }

  private startBoss(): void {
    this.phase = 'boss'; this.phaseTime = 0;
    this.ranger = buildRanger(); this.ranger.root.position.set(-16, 0, -9.2); this.ranger.root.scale.setScalar(RS); this.root.add(this.ranger.root);
    Object.assign(this.boss, { hp: this.boss.maxHp, x: -16, dir: 1, attackT: 3.5, lightT: 9, sweeping: 0, flash: 0, defeated: 0 });
    this.hud.show('RANGER RICK!', this.now, 3, '#ff6b6b'); this.sfx.horn();
  }

  private finish(won: boolean): void {
    this.phase = won ? 'victory' : 'gameover'; this.phaseTime = 0;
    if (won) { this.score += 1000; this.hud.show('SNACKS SECURED!', this.now, 4, '#80ed99'); this.sfx.victory(); this.startRain(); }
    else this.hud.show('RICK GOT AWAY', this.now, 4, '#ff6b6b');
    this.boss.sweeping = 0;
    if (this.score > this.best) { this.best = this.score; try { localStorage.setItem('raccoon-rampage.best', String(this.best)); } catch { /* private mode */ } }
  }

  /** Victory celebration: snacks rain down from the night sky in front of the raccoon. */
  private startRain(): void {
    for (let i = 0; i < 42; i++) {
      const m = buildSnackSprite(1300 + i, 0.32 + Math.random() * 0.18);
      const x = (Math.random() - 0.5) * 6; const z = -1.2 - Math.random() * 6;
      m.position.set(x, 6 + Math.random() * 5, z); (m.material as SpriteMaterial).rotation = Math.random() * 6;
      this.root.add(m);
      this.rain.push({ mesh: m, vel: new Vector3((Math.random() - 0.5) * 0.6, -1 - Math.random() * 2, (Math.random() - 0.5) * 0.6), spin: 2 + Math.random() * 5, delay: Math.random() * 2.2, landed: false });
    }
  }

  private updateRain(dt: number): void {
    for (const r of this.rain) {
      if (r.landed) continue;
      if (r.delay > 0) { r.delay -= dt; r.mesh.visible = false; continue; }
      r.mesh.visible = true;
      r.vel.y -= G * 0.45 * dt; r.mesh.position.addScaledVector(r.vel, dt);
      (r.mesh.material as SpriteMaterial).rotation += r.spin * dt;
      const floor = Math.abs(r.mesh.position.z - TABLE.z) < TABLE.depth / 2 && Math.abs(r.mesh.position.x) < TABLE.width / 2 + 0.3 ? TABLE.top + 0.12 : 0.16;
      if (r.mesh.position.y < floor) { r.mesh.position.y = floor; r.landed = true; }
    }
  }

  private clearActors(): void {
    for (const c of this.campers) this.root.remove(c.rig.root);
    for (const p of this.projectiles) this.root.remove(p.mesh);
    for (const f of this.flying) this.root.remove(f.mesh);
    for (const n of this.nets) this.root.remove(n.obj);
    for (const r of this.rain) this.root.remove(r.mesh);
    this.campers = []; this.projectiles = []; this.flying = []; this.nets = []; this.rain = [];
    if (this.ranger) { this.root.remove(this.ranger.root); this.ranger = null; }
  }

  // ---------- campers ----------
  private spawnCamper(o: { x?: number; z?: number; kid?: boolean; flash?: boolean; speed?: number; tutorial?: boolean } = {}): Camper {
    const seed = this.seed++;
    const rig = buildCamper(seed, { kid: o.kid, flashlight: o.flash });
    const dir = o.x !== undefined ? 1 : (Math.random() < 0.5 ? 1 : -1);
    const x = o.x ?? -dir * 15; const z = o.z ?? -(5.5 + Math.random() * 7);
    rig.root.position.set(x, 0, z); rig.flip.scale.x = dir;
    const snack = heldSnack(seed); rig.snackHolder.add(snack);
    this.root.add(rig.root);
    const c: Camper = { rig, seed, x, z, dir, speed: o.speed ?? 1.2, state: 'walk', t: 0, snack, kid: !!o.kid, scanCooldown: 2 + Math.random() * 3, warned: false, alive: true, tutorial: !!o.tutorial };
    this.campers.push(c);
    return c;
  }

  private updateCampers(dt: number): void {
    const PI = Math.PI;
    for (const c of this.campers) {
      if (!c.alive) continue;
      c.t += dt;
      const rig = c.rig; const swing = Math.sin(c.t * (c.state === 'flee' ? 17 : 8.5) * (c.kid ? 1.3 : 1));
      if (c.state === 'walk') {
        c.x += c.dir * c.speed * dt;
        rig.legL.rotation.z = swing * 0.45; rig.legR.rotation.z = -swing * 0.45;
        rig.armL.rotation.z = PI - 0.35 + swing * 0.08; rig.armR.rotation.z = PI - 0.12 - swing * 0.08; // proudly holding the snack up
        rig.body.position.y = Math.abs(swing) * 0.04; rig.body.rotation.z = 0;
        if (rig.flashlight) { rig.armR.rotation.z = 1.2 + swing * 0.15; c.scanCooldown -= dt; if (c.scanCooldown <= 0 && Math.abs(c.x) < 9) { c.state = 'scan'; c.t = 0; c.warned = false; } }
        if (Math.abs(c.x) > 17) this.despawn(c);
      } else if (c.state === 'scan') {
        rig.flip.scale.x = c.x > this.head.x ? -1 : 1; // turn towards the raccoon
        rig.legL.rotation.z = 0.12; rig.legR.rotation.z = -0.12; rig.body.position.y = 0;
        rig.armR.rotation.z = PI / 2 + 0.25 + Math.sin(c.t * 5) * 0.05;
        if (rig.beam && rig.flashlight) {
          rig.beam.visible = c.t > 0.3;
          // the beam swings from the side onto the raccoon, then past it
          rig.flashlight.getWorldPosition(this.v1); rig.beam.position.set(this.v1.x - c.x, this.v1.y, this.v1.z - c.z);
          const sweep = (1.5 - c.t) * 3.2 * (c.x > 0 ? 1 : -1);
          this.v2.set(this.head.x + sweep, this.head.y - 0.15, this.head.z); rig.beam.lookAt(this.v2);
          if (!c.warned && c.t > 0.3) { c.warned = true; this.hud.show('DUCK!', this.now, 1.2, '#fff3b0'); }
          if (c.t > 1.5 && c.t < 1.6 && !this.isDucking()) this.spotted();
        }
        if (c.t > 2.6) { c.state = 'walk'; c.t = 0; c.scanCooldown = 4 + Math.random() * 4; if (rig.beam) rig.beam.visible = false; rig.flip.scale.x = c.dir; }
      } else if (c.state === 'hit') {
        const decay = Math.max(0, 1 - c.t * 1.8);
        rig.body.rotation.z = Math.sin(c.t * 34) * 0.22 * decay; rig.body.position.y = Math.max(0, Math.sin(Math.min(PI, c.t * 6)) * 0.35);
        rig.armL.rotation.z = PI - 0.9 + Math.sin(c.t * 40) * 0.6; rig.armR.rotation.z = PI - 0.2 - Math.sin(c.t * 40) * 0.6;
        rig.legL.rotation.z = 0.5; rig.legR.rotation.z = -0.5;
        if (c.t > 0.6) { c.state = 'flee'; c.t = 0; c.speed = 4.5; }
      } else if (c.state === 'flee') {
        c.z -= c.speed * dt; c.x += c.dir * 0.8 * dt;
        rig.legL.rotation.z = swing * 0.8; rig.legR.rotation.z = -swing * 0.8; rig.armL.rotation.z = PI - 0.3 + swing * 0.5; rig.armR.rotation.z = PI - 0.3 - swing * 0.5;
        rig.body.rotation.z = -0.18; rig.body.position.y = Math.abs(swing) * 0.08;
        if (c.z < -34) this.despawn(c);
      } else if (c.state === 'idle') {
        rig.armL.rotation.z = PI - 0.4; rig.armR.rotation.z = PI - 0.2 + Math.sin(this.now * 3) * 0.25; // waves the snack around, taunting
        rig.body.position.y = Math.abs(Math.sin(this.now * 2.5)) * 0.06;
        rig.snackHolder.position.x = 0.1 + Math.sin(this.now * 3) * 0.05;
      }
      rig.root.position.x = c.x; rig.root.position.z = c.z;
      // paper puppets always face the viewer
      rig.stand.rotation.y = Math.atan2(this.head.x - c.x, this.head.z - c.z);
    }
    if (this.campers.length > 40) this.campers = this.campers.filter((c) => c.alive);
  }

  private despawn(c: Camper): void { c.alive = false; this.root.remove(c.rig.root); }

  private hitCamper(c: Camper, at: Vector3): void {
    if (c.state === 'hit' || c.state === 'flee') return;
    this.sfx.bonk(); this.sfx.yelp();
    if (c.rig.beam) c.rig.beam.visible = false;
    c.state = 'hit'; c.t = 0; c.rig.setFace(true);
    this.v3.set(c.x, c.rig.height + 0.35, c.z); this.fx.hit(this.v3);
    if (this.now - this.lastHit < 3.5) this.combo = Math.min(8, this.combo + 1); else this.combo = 1;
    this.lastHit = this.now;
    if (c.snack) {
      const held = c.snack; c.snack = null;
      held.getWorldPosition(this.v1); c.rig.snackHolder.remove(held);
      const snack = buildSnackSprite(c.seed); snack.position.copy(this.v1); this.root.add(snack);
      this.flying.push({ mesh: snack, from: this.v1.clone(), age: 0, dur: 1.1, value: (c.kid ? 200 : 100) * this.combo, alive: true });
    }
    if (this.combo >= 3) this.hud.show(`COMBO x${this.combo}!`, this.now, 1.1, '#ffb703');
    if (c.tutorial && this.phase === 'intro') { this.startWave(0); }
    void at;
  }

  private spotted(): void {
    this.sfx.spotted(); this.combo = 1;
    const lost = Math.min(2, this.snacks); this.snacks -= lost; this.score = Math.max(0, this.score - 150);
    this.hud.show(lost ? `SPOTTED! −${lost} SNACKS` : 'SPOTTED!', this.now, 1.6, '#ff6b6b');
    this.v3.set(this.head.x, this.head.y + 0.2, this.head.z - 1.6); this.fx.minus(this.v3, lost ? `-${lost} SNACKS` : 'SPOTTED');
  }

  // ---------- player ----------
  private updateHead(): void {
    const flat = this.visibilityState.peek() === VisibilityState.NonImmersive;
    if (flat) {
      const target = this.duckKey ? 0.95 : 1.45;
      this.camera.position.y += (target - this.camera.position.y) * 0.25;
      this.camera.getWorldPosition(this.head);
      this.standHeight = 1.45;
    } else {
      this.player.head.getWorldPosition(this.head);
      if (this.head.y > this.standHeight) this.standHeight = this.head.y; else this.standHeight -= (this.standHeight - this.head.y) * 0.0005;
    }
  }

  private isDucking(): boolean { return this.head.y < this.standHeight - 0.28; }

  private takeAmmo(near: Vector3 | null): TraySlot | null {
    let best: TraySlot | null = null; let bestD = Infinity;
    for (const s of this.tray) {
      if (s.taken) continue;
      s.mesh.getWorldPosition(this.v3);
      const d = near ? this.v3.distanceTo(near) : 0;
      if (d < bestD) { bestD = d; best = s; }
    }
    if (best && near && bestD > 0.45) {
      // generous "magic paws": anywhere over the table counts
      const overTable = near.y < TABLE.top + 0.5 && Math.abs(near.x) < 1.3 && near.z > TABLE.z - 0.6 && near.z < 0.3;
      if (!overTable) return null;
    }
    if (best) { best.taken = true; best.respawn = this.now + 1.2; this.sfx.pickup(); }
    return best;
  }

  private updateXRHands(): void {
    for (const hand of HANDS) {
      const pad = this.input.xr.gamepads[hand];
      const space = this.player.gripSpaces[hand];
      if (!pad || !space) continue;
      space.getWorldPosition(this.grip);
      const h = this.gripHist[hand]; h.i = (h.i + 1) % h.p.length; h.p[h.i].copy(this.grip); h.t[h.i] = this.now;
      const slot = this.held[hand];
      if (!slot) {
        if (this.now < this.stunnedUntil) continue;
        // xr-standard mapping: button 0 = trigger, 1 = squeeze (grip)
        let btn = -1;
        if (pad.getButtonDownByIdx(1)) btn = 1; else if (pad.getButtonDownByIdx(0)) btn = 0;
        if (btn >= 0) {
          const s = this.takeAmmo(this.grip);
          if (s) {
            this.held[hand] = s; this.heldButton[hand] = btn;
            this.camp.tray.remove(s.mesh); s.mesh.position.set(0, -0.02, -0.06); space.add(s.mesh);
            this.restartFromEnd();
          }
        }
      } else {
        s_release: {
          const still = pad.getButtonPressedByIdx(this.heldButton[hand]);
          if (still) break s_release;
          // velocity from the last ~80 ms of grip motion
          const newest = h.i; let oldest = newest;
          for (let k = 1; k < h.p.length; k++) { const idx = (newest - k + h.p.length) % h.p.length; if (this.now - h.t[idx] > 0.09) break; oldest = idx; }
          const dtv = Math.max(0.016, h.t[newest] - h.t[oldest]);
          this.v1.copy(h.p[newest]).sub(h.p[oldest]).divideScalar(dtv).multiplyScalar(1.7);
          space.remove(slot.mesh);
          this.launch(slot, this.grip, this.v1);
          this.held[hand] = null;
        }
      }
    }
  }

  private updateDesktop(): void {
    if (!this.mouse.clicked) return;
    this.mouse.clicked = false;
    if (this.restartFromEnd()) return;
    if (this.now < this.stunnedUntil) return;
    const s = this.takeAmmo(null); if (!s) return;
    // ray from the camera through the cursor
    this.v1.set(this.mouse.x, this.mouse.y, 0.5).unproject(this.camera).sub(this.head).normalize();
    let target: Vector3 | null = null; let bestT = Infinity;
    const consider = (cx: number, cy: number, cz: number, rad: number) => {
      this.v2.set(cx, cy, cz).sub(this.head); const t = this.v2.dot(this.v1); if (t <= 0) return;
      const d2 = this.v2.lengthSq() - t * t; if (d2 < rad * rad && t < bestT) { bestT = t; target = this.v3.copy(this.head).addScaledVector(this.v1, t).clone(); }
    };
    for (const c of this.campers) if (c.alive && c.state !== 'flee') consider(c.x, c.rig.height * 0.6, c.z, 0.9);
    if (this.ranger) { this.ranger.ranger.getWorldPosition(this.v2); consider(this.v2.x, this.v2.y + 0.7 * RS, this.v2.z, 1.2 * RS); }
    if (!target) {
      const t = this.v1.y < -0.02 ? -this.head.y / this.v1.y : 18;
      target = this.head.clone().addScaledVector(this.v1, Math.min(30, t));
    }
    const start = this.v2.copy(this.head); start.y -= 0.25; start.x += 0.2;
    const dist = start.distanceTo(target as Vector3); const tf = dist / 14 + 0.25;
    const vel = (target as Vector3).clone().sub(start).divideScalar(tf); vel.y += 0.5 * G * tf;
    this.camp.tray.remove(s.mesh);
    this.launch(s, start, vel);
  }

  private restartFromEnd(): boolean {
    if ((this.phase === 'victory' || this.phase === 'gameover') && this.phaseTime > 3) { this.enterIntro(); return true; }
    return false;
  }

  private launch(slot: TraySlot, from: Vector3, vel: Vector3): void {
    const speed = vel.length();
    if (speed < 2.5) vel.setLength(2.5); if (speed > 24) vel.setLength(24);
    this.aimAssist(from, vel);
    const mesh = buildAmmo(slot.kind); mesh.position.copy(from); this.root.add(mesh);
    this.projectiles.push({ mesh, vel: vel.clone(), age: 0, bounced: false, alive: true });
    this.sfx.throw();
    // return the tray item after a short delay
    slot.mesh.position.copy(slot.home); slot.mesh.visible = false; this.camp.tray.add(slot.mesh);
  }

  /** Nudges a throw towards the nearest target within ~14° so that VR throws feel fair. Moving targets are led by the flight time. */
  private aimAssist(from: Vector3, vel: Vector3): void {
    const hs = Math.hypot(vel.x, vel.z); if (hs < 0.5) return;
    const dirX = vel.x / hs; const dirZ = vel.z / hs; const sp = Math.max(6, hs);
    let bx = 0; let bz = 0; let by = 0; let best = Math.cos(0.25); let found = false;
    const test = (x: number, y: number, z: number, vx: number) => {
      const dz = z - from.z; const d0 = Math.hypot(x - from.x, dz); if (d0 < 1) return;
      const px = x + vx * (d0 / sp); const dx = px - from.x; const d = Math.hypot(dx, dz);
      const c = (dx * dirX + dz * dirZ) / d; if (c > best) { best = c; bx = px; by = y; bz = z; found = true; }
    };
    for (const c of this.campers) if (c.alive && (c.state === 'walk' || c.state === 'scan' || c.state === 'idle')) test(c.x, c.rig.height * 0.7, c.z, c.state === 'walk' ? c.dir * c.speed : 0);
    if (this.ranger && this.boss.defeated === 0) { this.ranger.ranger.getWorldPosition(this.v3); test(this.v3.x, this.v3.y + 0.7 * RS, this.v3.z, this.boss.dir * (this.boss.hp <= this.boss.maxHp / 2 ? 3.4 : 2.2)); }
    if (!found) return;
    const dx = bx - from.x; const dz = bz - from.z; const d = Math.hypot(dx, dz);
    const t = d / sp;
    const nvx = dx / t; const nvz = dz / t;
    // keep a little of the player's own direction, but solve the arc height exactly so the snack drops onto the target
    const vx = vel.x * 0.15 + nvx * 0.85; const vz = vel.z * 0.15 + nvz * 0.85;
    const tf = d / Math.max(0.5, Math.hypot(vx, vz));
    vel.set(vx, (by - from.y + 0.5 * G * tf * tf) / tf, vz);
  }

  // ---------- simulation ----------
  private updateProjectiles(dt: number): void {
    // sub-step so fast throws cannot tunnel through a camper on a long frame
    const steps = Math.max(1, Math.ceil(dt / 0.012)); const h = dt / steps;
    for (let i = 0; i < steps; i++) this.stepProjectiles(h);
    if (this.projectiles.length > 30) this.projectiles = this.projectiles.filter((p) => p.alive);
  }

  private stepProjectiles(dt: number): void {
    for (const p of this.projectiles) {
      if (!p.alive) continue;
      p.age += dt; p.vel.y -= G * dt; p.mesh.position.addScaledVector(p.vel, dt); (p.mesh.material as SpriteMaterial).rotation += dt * 9;
      const pos = p.mesh.position;
      for (const c of this.campers) {
        if (!c.alive || c.state === 'hit' || c.state === 'flee') continue;
        const hgt = c.rig.height;
        const dx = pos.x - c.x; const dz = pos.z - c.z;
        if (dx * dx + dz * dz < 0.42 * 0.42 && pos.y > 0.2 && pos.y < hgt + 0.25) { this.hitCamper(c, pos); p.alive = false; break; }
      }
      if (p.alive && this.ranger && this.boss.defeated === 0) {
        this.ranger.ranger.getWorldPosition(this.v1);
        this.ranger.hat.getWorldPosition(this.v2); this.v2.y += 0.1 * RS; // hat
        if (pos.distanceTo(this.v2) < 0.42 * RS) { this.damageBoss(2, true); p.alive = false; }
        else { this.v2.copy(this.v1); this.v2.y += 0.62 * RS; if (pos.distanceTo(this.v2) < 0.6 * RS) { this.damageBoss(1, false); p.alive = false; } }
        if (p.alive) { this.ranger.jeep.getWorldPosition(this.v2); if (Math.abs(pos.x - this.v2.x) < 1.8 * RS && Math.abs(pos.z - this.v2.z) < 0.9 && pos.y < 1.3 * RS) { this.sfx.bonk(); this.fx.hit(pos, 'CLANG!'); p.alive = false; } }
      }
      if (p.alive && pos.y < 0.05) { if (!p.bounced && p.vel.length() > 3) { p.bounced = true; p.vel.y = Math.abs(p.vel.y) * 0.3; p.vel.x *= 0.5; p.vel.z *= 0.5; pos.y = 0.05; } else { p.vel.set(0, 0, 0); pos.y = 0.04; } }
      if (p.age > 5 || pos.z < -45 || Math.abs(pos.x) > 40) p.alive = false;
      if (!p.alive) this.root.remove(p.mesh);
    }
  }

  private updateSnacks(dt: number): void {
    for (const f of this.flying) {
      if (!f.alive) continue;
      f.age += dt; const k = Math.min(1, f.age / f.dur);
      if (f.age < 0) { f.mesh.visible = false; continue; } f.mesh.visible = true;
      f.mesh.position.lerpVectors(f.from, this.stashPos, k); f.mesh.position.y += Math.sin(k * Math.PI) * 3.5; (f.mesh.material as SpriteMaterial).rotation += dt * 8;
      const sz = 0.38 * (1 - 0.55 * k); f.mesh.scale.set(sz, sz, 1);
      if (k >= 1) { f.alive = false; this.root.remove(f.mesh); this.snacks++; this.score += f.value; this.sfx.snack(this.combo); this.v3.copy(this.stashPos); this.v3.y += 0.35; this.fx.points(this.v3, f.value); }
    }
    if (this.flying.length > 20) this.flying = this.flying.filter((f) => f.alive);
  }

  private updateTray(): void {
    for (const s of this.tray) if (s.taken && this.now > s.respawn && !this.isHeld(s)) { s.taken = false; s.mesh.visible = true; s.mesh.position.copy(s.home); s.mesh.scale.set(0.13, 0.13, 1); }
  }
  private isHeld(s: TraySlot): boolean { return this.held.left === s || this.held.right === s; }

  // ---------- boss ----------
  private damageBoss(dmg: number, hat: boolean): void {
    if (!this.ranger || this.boss.defeated) return;
    this.sfx.bonk(); this.boss.hp -= dmg; this.boss.flash = 0.25; this.ouch = 0.4;
    this.ranger.ranger.getWorldPosition(this.v3); this.v3.y += hat ? 1.9 : 1.2; this.fx.hit(this.v3, hat ? 'HAT TRICK!' : undefined);
    if (hat) this.hatPop = 0.8;
    if (this.now - this.lastHit < 3.5) this.combo = Math.min(8, this.combo + 1); else this.combo = 1;
    this.lastHit = this.now; this.score += (hat ? 150 : 80) * this.combo;

    if (this.boss.hp <= this.boss.maxHp / 2 && this.boss.hp + dmg > this.boss.maxHp / 2) { this.hud.show('RICK IS ANGRY!', this.now, 2, '#ff6b6b'); this.sfx.horn(); }
    if (this.boss.hp <= 0) { this.boss.defeated = 0.01; this.sfx.victory(); this.ranger.ranger.getWorldPosition(this.v3); this.v3.y += 1.6; this.fx.big(this.v3, 'KA-BOOM!', '#ff9f1c', '#ffffff'); for (let i = 0; i < 10; i++) { const s = buildSnackSprite(900 + i); this.ranger.jeep.getWorldPosition(this.v1); this.v1.y += 1.5 + i * 0.05; s.position.copy(this.v1); this.root.add(s); this.flying.push({ mesh: s, from: this.v1.clone(), age: -i * 0.12, dur: 1.3, value: 100, alive: true }); } }
  }

  private updateBoss(dt: number): void {
    const r = this.ranger; if (!r) return;
    const b = this.boss;
    r.stand.rotation.y = Math.atan2(this.head.x - r.root.position.x, this.head.z - r.root.position.z);
    this.ouch = Math.max(0, this.ouch - dt);
    // hat knocked up into the air, then it drops back on his head
    this.hatPop = Math.max(0, this.hatPop - dt);
    r.hat.position.y = 0.68 + Math.sin(Math.min(1, this.hatPop / 0.8) * Math.PI) * 0.7; r.hat.rotation.z = this.hatPop > 0 ? Math.sin(this.hatPop * 14) * 0.6 : 0;
    if (b.defeated > 0) {
      b.defeated += dt; r.root.position.x += 9 * dt; r.flip.scale.x = 1; r.flip.rotation.z = Math.sin(b.defeated * 12) * 0.12;
      r.ranger.position.y = 1.0 + Math.abs(Math.sin(b.defeated * 10)) * 0.4; r.setFace('ouch'); r.beam.visible = false;
      for (const w of r.wheels) w.rotation.z -= 9 * dt / 0.44;
      if (b.defeated > 2.6) this.finish(true);
      return;
    }
    const angry = b.hp <= b.maxHp / 2; const speed = angry ? 3.4 : 2.2;
    r.setFace(this.ouch > 0 ? 'ouch' : angry ? 'angry' : 'grumpy');
    if (b.x < -9) b.dir = 1; if (b.x > 9) b.dir = -1;
    let v = speed * b.dir;
    if (r.root.position.x < -9.5) { r.root.position.x += 6 * dt; b.x = r.root.position.x; v = 6; } else { b.x += b.dir * speed * dt; r.root.position.x = b.x; }
    r.flip.scale.x = v >= 0 ? 1 : -1;
    for (const w of r.wheels) w.rotation.z -= Math.abs(v) * dt / 0.44;
    r.jeep.position.y = Math.abs(Math.sin(this.now * 9)) * 0.03; // bumpy ride
    // net attacks
    b.attackT -= dt; r.armR.rotation.z = b.attackT < 0.4 ? Math.PI - 0.4 : 0.35 + Math.sin(this.now * 4) * 0.08;
    if (b.attackT <= 0) {
      b.attackT = angry ? 2.1 : 3.1;
      const net = buildNet(); r.ranger.getWorldPosition(this.v1); this.v1.y += 1.2; net.position.copy(this.v1); this.root.add(net);
      const tf = angry ? 1.35 : 1.7;
      // aim at standing head height, so ducking always dodges (even if the player is already crouched)
      this.v2.set(this.head.x, this.standHeight - 0.05, this.head.z).sub(this.v1).divideScalar(tf); this.v2.y += 0.5 * G * tf;
      this.nets.push({ obj: net, vel: this.v2.clone(), age: 0, alive: true }); this.sfx.netWhoosh();
      if (this.nets.length === 1 || Math.random() < 0.3) this.hud.show('DODGE THE NET!', this.now, 1, '#bde0fe');
    }
    // searchlight sweep in phase two
    b.lightT -= dt;
    if (angry && b.lightT <= 0) { b.lightT = 7; b.sweeping = 2.4; this.hud.show('SEARCHLIGHT! DUCK!', this.now, 1.3, '#fff3b0'); }
    if (b.sweeping > 0) {
      b.sweeping -= dt; r.light.scale.setScalar(1.6); r.beam.visible = true;
      r.lamp.getWorldPosition(this.v1); r.beam.position.set(this.v1.x - r.root.position.x, this.v1.y, this.v1.z - r.root.position.z);
      this.v2.set(this.head.x + (b.sweeping - 1.0) * 4, this.head.y - 0.1, this.head.z); r.beam.lookAt(this.v2);
      if (b.sweeping < 1.0 && b.sweeping + dt >= 1.0 && !this.isDucking()) this.spotted();
    } else { r.light.scale.setScalar(0.9); r.beam.visible = false; }
    if (this.phaseTime > 110) this.finish(false);
  }

  private updateNets(dt: number): void {
    for (const n of this.nets) {
      if (!n.alive) continue;
      n.age += dt; n.vel.y -= G * dt; n.obj.position.addScaledVector(n.vel, dt); (n.obj.material as SpriteMaterial).rotation += dt * 4;
      if (!this.isDucking() && n.obj.position.distanceTo(this.head) < 0.5) { // ducking always dodges the net
        n.alive = false; this.root.remove(n.obj); this.sfx.netHit(); this.combo = 1;
        const lost = Math.min(3, this.snacks); this.snacks -= lost; this.score = Math.max(0, this.score - 200); this.stunnedUntil = this.now + 1.2;
        this.hud.show('NETTED!', this.now, 1.4, '#ff6b6b'); this.v3.set(this.head.x, this.head.y, this.head.z - 1.2); this.fx.hit(this.v3, 'SPLAT!');
        for (const hand of HANDS) { const s = this.held[hand]; if (s) { s.mesh.parent?.remove(s.mesh); s.mesh.visible = false; s.mesh.position.copy(s.home); this.camp.tray.add(s.mesh); this.held[hand] = null; } }
      } else if (n.obj.position.y < -0.5 || n.age > 4) { n.alive = false; this.root.remove(n.obj); }
    }
    if (this.nets.length > 10) this.nets = this.nets.filter((n) => n.alive);
  }

  // ---------- frame ----------
  update(delta: number): void {
    const vis = this.visibilityState.peek();
    if (vis === VisibilityState.VisibleBlurred || vis === VisibilityState.Hidden) return;
    const dt = Math.min(0.05, delta);
    this.now += dt; this.phaseTime += dt;
    this.updateHead();
    if (vis === VisibilityState.NonImmersive) this.updateDesktop(); else this.updateXRHands();
    this.updateTray(); this.updateCampers(dt); this.updateProjectiles(dt); this.updateSnacks(dt); this.updateNets(dt); this.updateRain(dt);

    if (this.phase === 'wave') {
      const w = WAVES[this.waveIdx];
      this.spawnTimer -= dt;
      const active = this.campers.filter((c) => c.alive && c.state !== 'flee').length;
      if (this.spawnTimer <= 0 && active < w.max && this.phaseTime < w.dur - 3) {
        this.spawnTimer = w.every * (0.7 + Math.random() * 0.6);
        const kid = Math.random() < w.kid; const flash = !kid && Math.random() < w.flash;
        this.spawnCamper({ kid, flash, speed: (w.speed[0] + Math.random() * (w.speed[1] - w.speed[0])) * (kid ? 1.5 : 1) });
      }
      if (this.phaseTime > w.dur) { this.phase = 'break'; this.phaseTime = 0; this.hud.show(this.waveIdx < 2 ? 'WAVE CLEAR!' : 'UH OH…', this.now, 2.2, '#80ed99'); }
    } else if (this.phase === 'break') {
      if (this.phaseTime > 3) { if (this.waveIdx < WAVES.length - 1) this.startWave(this.waveIdx + 1); else this.startBoss(); }
    } else if (this.phase === 'boss') this.updateBoss(dt);

    // fire flicker
    const f = this.camp.fire; f.light.intensity = 10 + Math.sin(this.now * 13) * 1.6 + Math.sin(this.now * 7.3) * 1.2;
    for (let i = 0; i < f.flames.length; i++) { const fl = f.flames[i]; fl.scale.y = 0.88 + Math.sin(this.now * (9 + i * 2) + i) * 0.14; fl.scale.x = 1 + Math.sin(this.now * (7 + i) + i * 2) * 0.08; fl.rotation.z = Math.sin(this.now * (3 + i)) * 0.06; }
    (f.glow.material as SpriteMaterial).opacity = 0.5 + Math.sin(this.now * 11) * 0.06;
    for (let i = 0; i < this.camp.clouds.length; i++) { const cl = this.camp.clouds[i]; cl.position.x += dt * (0.25 + i * 0.05); if (cl.position.x > 70) cl.position.x = -70; }
    this.fx.eye.copy(this.head); this.fx.update(dt);
    this.hud.tick(this.now);
    this.hudTimer -= dt;
    if (this.hudTimer <= 0) { this.hudTimer = 0.1; this.drawHud(); }
  }

  private drawHud(): void {
    const remaining = this.phase === 'wave' ? Math.max(0, WAVES[this.waveIdx].dur - this.phaseTime) : this.phase === 'boss' ? Math.max(0, 110 - this.phaseTime) : 0;
    const time = remaining ? `${Math.floor(remaining / 60)}:${String(Math.floor(remaining % 60)).padStart(2, '0')}` : '';
    const wave = this.phase === 'intro' ? 'RACCOON RAMPAGE' : this.phase === 'boss' ? 'BOSS: RANGER RICK' : this.phase === 'victory' ? 'VICTORY!' : this.phase === 'gameover' ? 'GAME OVER' : `${WAVES[this.waveIdx].name}: ${WAVE_TITLES[this.waveIdx]}`;
    const flat = this.visibilityState.peek() === VisibilityState.NonImmersive;
    const hint = this.phase === 'intro' ? (flat ? 'Click on Ted to throw a marshmallow and start the night!' : 'Grab a snack from the table (grip or trigger) and throw it at Ted to start!')
      : this.phase === 'boss' ? 'Hit Ranger Rick (hat = double damage). Dodge his nets!'
      : this.phase === 'victory' || this.phase === 'gameover' ? `Best: ${this.best}. ${flat ? 'Click' : 'Grab a snack'} to play again.`
      : this.phase === 'break' ? 'Get ready…' : WAVES[this.waveIdx].hint;
    this.hud.draw({ wave, score: this.score, snacks: this.snacks, combo: this.combo, time, hint, bossHp: this.phase === 'boss' && this.ranger ? Math.max(0, this.boss.hp / this.boss.maxHp) : null });
  }
}

export type { Object3D };
