/** Tiny Web Audio synthesiser: every sound is generated, no audio files. */
export class Sfx {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private crickets: AudioBufferSourceNode | null = null;

  unlock(): void {
    try {
      if (!this.ctx) {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        this.ctx = new AC();
        this.master = this.ctx.createGain(); this.master.gain.value = 0.55; this.master.connect(this.ctx.destination);
        this.startAmbience();
      }
      if (this.ctx.state === 'suspended') void this.ctx.resume();
    } catch { /* audio unavailable */ }
  }

  private tone(freq: number, dur: number, type: OscillatorType, vol: number, slideTo?: number, delay = 0): void {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + delay;
    const o = this.ctx.createOscillator(); const g = this.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.master); o.start(t); o.stop(t + dur + 0.02);
  }

  private noise(dur: number, vol: number, freq: number): void {
    if (!this.ctx || !this.master) return;
    const len = Math.floor(this.ctx.sampleRate * dur); const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate); const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const src = this.ctx.createBufferSource(); src.buffer = buf;
    const f = this.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = 0.8;
    const g = this.ctx.createGain(); g.gain.value = vol;
    src.connect(f); f.connect(g); g.connect(this.master); src.start();
  }

  private startAmbience(): void {
    if (!this.ctx || !this.master) return;
    const len = this.ctx.sampleRate * 2; const buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate); const d = buf.getChannelData(0);
    for (let i = 0; i < len; i++) { const chirp = Math.sin(i / this.ctx.sampleRate * 2 * Math.PI * 4300) * (Math.sin(i / this.ctx.sampleRate * 2 * Math.PI * 3) > 0.92 ? 1 : 0); d[i] = chirp * 0.06 + (Math.random() * 2 - 1) * 0.004; }
    const src = this.ctx.createBufferSource(); src.buffer = buf; src.loop = true;
    const g = this.ctx.createGain(); g.gain.value = 0.35; src.connect(g); g.connect(this.master); src.start(); this.crickets = src;
  }

  throw(): void { this.noise(0.18, 0.5, 900); }
  pickup(): void { this.tone(660, 0.06, 'triangle', 0.2); }
  bonk(): void { this.tone(220, 0.16, 'square', 0.25, 90); this.noise(0.08, 0.4, 400); }
  yelp(): void { this.tone(520 + Math.random() * 200, 0.22, 'sawtooth', 0.12, 900); }
  snack(combo: number): void { const base = 520 * Math.pow(1.06, Math.min(combo, 12)); this.tone(base, 0.09, 'triangle', 0.22); this.tone(base * 1.5, 0.12, 'triangle', 0.18, undefined, 0.07); }
  miss(): void { this.tone(180, 0.1, 'sine', 0.12); }
  spotted(): void { this.tone(880, 0.12, 'square', 0.18); this.tone(660, 0.18, 'square', 0.18, undefined, 0.13); }
  wave(): void { [392, 523, 659, 784].forEach((f, i) => this.tone(f, 0.16, 'triangle', 0.2, undefined, i * 0.11)); }
  horn(): void { this.tone(196, 0.5, 'sawtooth', 0.22); this.tone(247, 0.5, 'sawtooth', 0.16, undefined, 0.05); }
  netWhoosh(): void { this.noise(0.4, 0.35, 500); }
  netHit(): void { this.tone(140, 0.4, 'sawtooth', 0.25, 60); }
  victory(): void { [523, 659, 784, 1046, 784, 1046].forEach((f, i) => this.tone(f, 0.2, 'triangle', 0.22, undefined, i * 0.14)); }
}
