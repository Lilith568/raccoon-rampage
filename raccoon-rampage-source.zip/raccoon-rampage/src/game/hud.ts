/** World-space comic HUD: a comic-panel scoreboard beside the table and big comic lettering for announcements. */
import { BackSide, CanvasTexture, CylinderGeometry, DoubleSide, Group, Mesh, MeshBasicMaterial, MeshToonMaterial, PlaneGeometry } from '@iwsdk/core';
import { canvas, halftone, INK, letter, poly, rrect, tex, COMIC_FONT, ink, fill, shadeColor } from '../art/ink.js';

export interface HudState { wave: string; score: number; snacks: number; combo: number; time: string; hint: string; bossHp: number | null; }

export class Hud {
  readonly board = new Group();
  readonly banner = new Group();
  private bCanvas: HTMLCanvasElement; private bTex: CanvasTexture;
  private nCanvas: HTMLCanvasElement; private nTex: CanvasTexture; private nMesh: Mesh;
  private last = '';
  private bannerUntil = 0;
  private bannerStart = 0;

  constructor() {
    [this.bCanvas] = canvas(768, 448); this.bTex = tex(this.bCanvas);
    const face = new Mesh(new PlaneGeometry(0.96, 0.56), new MeshBasicMaterial({ map: this.bTex, toneMapped: false, transparent: true, alphaTest: 0.1 }));
    this.board.add(face);
    const post = new CylinderGeometry(0.03, 0.035, 1.25, 10);
    const pm = new Mesh(post, new MeshToonMaterial({ color: '#6b4426' })); pm.position.set(0, -0.86, -0.02); this.board.add(pm);
    const po = new Mesh(post, new MeshBasicMaterial({ color: INK, side: BackSide })); po.position.copy(pm.position); po.scale.set(1.35, 1.01, 1.35); this.board.add(po);
    this.board.position.set(-0.9, 1.42, -1.3); this.board.rotation.y = 0.5; this.board.name = 'Scoreboard';

    [this.nCanvas] = canvas(1024, 300); this.nTex = tex(this.nCanvas);
    this.nMesh = new Mesh(new PlaneGeometry(4.4, 1.29), new MeshBasicMaterial({ map: this.nTex, transparent: true, depthWrite: false, side: DoubleSide, toneMapped: false, fog: false }));
    this.banner.add(this.nMesh); this.banner.position.set(0, 3.1, -7); this.banner.visible = false; this.banner.name = 'Banner';
  }

  draw(s: HudState): void {
    const key = JSON.stringify(s);
    if (key === this.last) return; this.last = key;
    const g = this.bCanvas.getContext('2d')!; const W = 768; const H = 448;
    g.clearRect(0, 0, W, H);
    // comic panel with a hard drop shadow
    g.fillStyle = INK; g.fillRect(24, 24, W - 30, H - 30);
    const panel = rrect(8, 8, W - 30, H - 30, 10);
    ink(g, panel, '#fff4dc', 7);
    halftone(g, panel, W, 0, W - 300, 260, '#f6d6a6', 18);
    // title strip
    const strip = poly([8, 8, W - 22, 8, W - 22, 86, 8, 96]); ink(g, strip, '#e63946', 5);
    letter(g, s.wave, 30, 52, 50, '#ffd23f', { maxW: s.time ? W - 210 : W - 80, outline: 9 });
    if (s.time) { ink(g, rrect(W - 170, 22, 132, 56, 10), '#ffffff', 5); letter(g, s.time, W - 104, 52, 42, '#15110e', { align: 'center', outline: 0.01, shadow: false }); }
    letter(g, String(s.score), 34, 168, 116, '#ffd23f', { outline: 16 });
    letter(g, `POINTS · ${s.snacks} SNACKS STOLEN`, 38, 248, 34, '#3a86ff', { outline: 7, maxW: W - 260 });
    if (s.combo > 1) {
      const cx = W - 120; const cy = 176; const pts: number[] = [];
      for (let i = 0; i < 24; i++) { const a = i / 24 * Math.PI * 2; const r = i % 2 ? 54 : 84; pts.push(cx + Math.cos(a) * r, cy + Math.sin(a) * r * 0.85); }
      ink(g, poly(pts), '#ff9f1c', 6); letter(g, `x${s.combo}`, cx, cy + 4, 70, '#ffffff', { align: 'center', outline: 10 });
    }
    let y = 300;
    if (s.bossHp !== null) {
      ink(g, rrect(34, 282, W - 100, 42, 10), '#3b2b2b', 5);
      if (s.bossHp > 0) fill(g, rrect(40, 288, (W - 112) * s.bossHp, 30, 8), '#e63946');
      letter(g, 'RANGER RICK', 52, 304, 28, '#ffffff', { outline: 6, shadow: false });
      y = 352;
    }
    // hint in comic lettering, wrapped
    g.font = `30px ${COMIC_FONT}`;
    const words = s.hint.toUpperCase().split(' '); let line = ''; const maxW = W - 90;
    for (const w of words) { const t = line ? `${line} ${w}` : w; if (g.measureText(t).width > maxW && line) { letter(g, line, 36, y, 30, '#15110e', { outline: 0.01, shadow: false }); line = w; y += 34; } else line = t; }
    if (line) letter(g, line, 36, y, 30, '#15110e', { outline: 0.01, shadow: false });
    this.bTex.needsUpdate = true;
  }

  show(text: string, now: number, seconds = 2.2, color = '#ffd23f'): void {
    const g = this.nCanvas.getContext('2d')!; const W = 1024; const H = 300;
    g.clearRect(0, 0, W, H);
    // jagged white comic burst behind the lettering
    const pts: number[] = []; const n = 22;
    for (let i = 0; i < n * 2; i++) { const a = i / (n * 2) * Math.PI * 2; const r = i % 2 ? 0.8 : 1; pts.push(W / 2 + Math.cos(a) * 500 * r, H / 2 + Math.sin(a) * 140 * r); }
    const burst = poly(pts); ink(g, burst, '#ffffff', 8);
    halftone(g, burst, W / 2, H / 2, W / 2, H, shadeColor(color, 0.45), 16);
    g.save(); g.translate(W / 2, H / 2 + 6); g.rotate(-0.04); letter(g, text.toUpperCase(), 0, 0, 120, color, { align: 'center', maxW: W - 200, outline: 18 }); g.restore();
    this.nTex.needsUpdate = true; this.banner.visible = true; this.bannerUntil = now + seconds; this.bannerStart = now;
  }

  tick(now: number): void {
    if (this.banner.visible && now > this.bannerUntil) this.banner.visible = false;
    if (this.banner.visible) {
      const age = now - this.bannerStart; const pop = age < 0.18 ? 0.4 + (age / 0.18) * 0.75 : 1.15 - Math.min(0.15, (age - 0.18) * 1.2);
      this.nMesh.scale.setScalar(pop * (1 + Math.sin(now * 9) * 0.015));
      (this.nMesh.material as MeshBasicMaterial).opacity = Math.min(1, (this.bannerUntil - now) * 3);
    }
  }
}
