/** Comic hit effects: "BONK!" bursts and floating "+200" numbers that pop up where things happen. */
import { Group, Sprite, SpriteMaterial, Vector3 } from '@iwsdk/core';
import { burstTexture, numberTexture } from '../art/props.js';

interface Pop { s: Sprite; age: number; life: number; size: number; rise: number; alive: boolean; }

const HIT_WORDS = ['BONK!', 'POW!', 'WHAM!', 'THUNK!', 'BOP!'];
const COLORS: [string, string][] = [['#ffd23f', '#e63946'], ['#ffffff', '#3a86ff'], ['#ff9f1c', '#15110e'], ['#8ac926', '#ffffff']];

export class Fx {
  readonly root = new Group();
  private pops: Pop[] = [];
  private n = 0;

  private spawn(map: SpriteMaterial['map'], at: Vector3, size: number, life: number, rise: number): void {
    let p = this.pops.find((q) => !q.alive);
    if (!p) { const s = new Sprite(new SpriteMaterial({ transparent: true, depthTest: false, depthWrite: false, toneMapped: false, fog: false })); s.renderOrder = 10; this.root.add(s); p = { s, age: 0, life, size, rise, alive: false }; this.pops.push(p); }
    const m = p.s.material as SpriteMaterial; m.map = map; m.needsUpdate = true; m.rotation = (Math.random() - 0.5) * 0.4;
    p.s.position.copy(at); p.age = 0; p.life = life; p.size = size; p.rise = rise; p.alive = true; p.s.visible = true;
  }

  /** Viewer position, so far-away bursts are drawn bigger and stay readable. */
  readonly eye = new Vector3(0, 1.6, 0);
  private far(at: Vector3, base: number): number { return base * Math.max(1, at.distanceTo(this.eye) / 6); }

  hit(at: Vector3, word?: string): void {
    const w = word ?? HIT_WORDS[this.n++ % HIT_WORDS.length]; const [c, t] = COLORS[this.n % COLORS.length];
    this.spawn(burstTexture(w, c, t), at, this.far(at, 1.3), 0.75, 0.6);
  }
  big(at: Vector3, word: string, color = '#ffd23f', text = '#e63946'): void { this.spawn(burstTexture(word, color, text), at, this.far(at, 2.4), 1.1, 0.4); }
  points(at: Vector3, value: number, color = '#ffd23f'): void { this.spawn(numberTexture(`+${value}`, color), at, 0.7, 1.0, 1.0); }
  minus(at: Vector3, text: string): void { this.spawn(numberTexture(text, '#ff6b6b'), at, 0.6, 1.2, 0.6); }

  update(dt: number): void {
    for (const p of this.pops) {
      if (!p.alive) continue;
      p.age += dt; const k = p.age / p.life;
      if (k >= 1) { p.alive = false; p.s.visible = false; continue; }
      const pop = k < 0.15 ? 0.3 + (k / 0.15) * 0.9 : 1.2 - Math.min(0.2, (k - 0.15) * 0.8);
      const img = (p.s.material as SpriteMaterial).map?.image as HTMLCanvasElement | undefined;
      const aspect = img ? img.height / img.width : 0.75;
      p.s.scale.set(p.size * pop, p.size * pop * aspect, 1);
      p.s.position.y += p.rise * dt;
      (p.s.material as SpriteMaterial).opacity = k > 0.7 ? 1 - (k - 0.7) / 0.3 : 1;
    }
  }
}
