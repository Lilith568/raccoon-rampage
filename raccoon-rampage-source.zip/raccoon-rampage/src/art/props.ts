/** Hand-drawn comic props: throwables, snacks, nets, glows, raccoon paws and "BONK!" bursts. */
import {
  AdditiveBlending, BackSide, CanvasTexture, ConeGeometry, CylinderGeometry, DataTexture, Group, Mesh, MeshBasicMaterial, MeshToonMaterial, NearestFilter,
  RedFormat, SphereGeometry, Sprite, SpriteMaterial,
} from '@iwsdk/core';
import { blob, canvas, circle, COMIC_FONT, curve, ellipse, fill, halftone, ink, INK, letter, line, nightShade, poly, rrect, shadeColor, tex, within } from './ink.js';

export type AmmoKind = 'marshmallow' | 'can' | 'pinecone' | 'apple';
export const AMMO_KINDS: AmmoKind[] = ['marshmallow', 'can', 'pinecone', 'apple'];

const ammoCache = new Map<AmmoKind, CanvasTexture>();
export function ammoTexture(kind: AmmoKind): CanvasTexture {
  let t = ammoCache.get(kind); if (t) return t;
  const [c, g] = canvas(160, 160);
  if (kind === 'marshmallow') {
    const top = ellipse(80, 54, 50, 22); const side = rrect(30, 54, 100, 64, 10);
    ink(g, side, '#fbf6ee', 8); ink(g, top, '#ffffff', 8);
    within(g, side, () => { fill(g, ellipse(36, 100, 26, 60), '#d6d3e8'); fill(g, rrect(30, 108, 100, 20, 0), '#f3c58f'); });
    line(g, curve([40, 120, 80, 128, 120, 120]), 6);
  } else if (kind === 'can') {
    const body = rrect(42, 22, 76, 120, 14); ink(g, body, '#e63946', 8);
    within(g, body, () => { fill(g, rrect(42, 60, 76, 40, 0), '#ffffff'); letter(g, 'FIZZ', 80, 80, 30, '#e63946', { align: 'center', outline: 5, shadow: false }); fill(g, ellipse(48, 80, 14, 70), '#00000033'); fill(g, rrect(98, 22, 8, 120, 4), '#ffffff66'); });
    ink(g, ellipse(80, 24, 36, 10), '#c0c6d0', 6);
  } else if (kind === 'pinecone') {
    const p = blob([80, 14, 116, 50, 124, 96, 104, 136, 80, 148, 56, 136, 36, 96, 44, 50]); ink(g, p, '#8a5a35', 8);
    within(g, p, () => { for (let y = 30; y < 150; y += 20) for (let x = 30 + (y % 40 ? 10 : 0); x < 140; x += 22) { line(g, curve([x - 10, y, x, y + 12, x + 10, y]), 5, '#5a3a22'); } fill(g, ellipse(40, 100, 20, 60), '#00000033'); });
  } else {
    const p = blob([80, 44, 118, 34, 140, 70, 130, 120, 100, 146, 80, 138, 60, 146, 30, 120, 20, 70, 42, 34]); ink(g, p, '#e5383b', 8);
    within(g, p, () => { fill(g, ellipse(40, 100, 30, 50), '#a4161a'); fill(g, ellipse(106, 66, 14, 22, 0.4), '#ffb3b3'); });
    line(g, curve([80, 46, 76, 26, 86, 12]), 8, '#5a3a22'); ink(g, blob([88, 30, 116, 14, 124, 28, 100, 40]), '#70e000', 5);
  }
  t = tex(c); ammoCache.set(kind, t); return t;
}

export function buildAmmo(kind: AmmoKind): Sprite {
  const m = new SpriteMaterial({ map: ammoTexture(kind), alphaTest: 0.5, toneMapped: false });
  const s = new Sprite(m); s.scale.set(0.13, 0.13, 1); s.name = `ammo-${kind}`;
  return s;
}

// ---------- snacks ----------
const snackCache = new Map<number, CanvasTexture>();
export function snackTexture(seed: number): CanvasTexture {
  const k = Math.abs(seed) % 5; let t = snackCache.get(k); if (t) return t;
  const [c, g] = canvas(256, 256);
  if (k === 0) { // chips bag
    const bag = poly([46, 40, 210, 40, 222, 70, 214, 200, 224, 228, 32, 228, 42, 200, 34, 70]); ink(g, bag, '#ffd23f', 10);
    within(g, bag, () => { fill(g, circle(128, 120, 58), '#ff4d4d'); fill(g, ellipse(60, 140, 40, 110), nightShade('#ffd23f')); });
    letter(g, 'CHIPS', 128, 124, 46, '#ffffff', { align: 'center', outline: 7, shadow: false });
    for (const x of [60, 90, 120, 150, 180]) line(g, curve([x, 44, x + 6, 50, x + 12, 44]), 4);
  } else if (k === 1) { // hot dog
    const bun = blob([20, 140, 70, 110, 186, 110, 236, 140, 210, 180, 46, 180]); ink(g, bun, '#f4a259', 10);
    const sausage = blob([10, 128, 60, 104, 196, 104, 246, 128, 196, 146, 60, 146]); ink(g, sausage, '#c1440e', 9);
    line(g, curve([40, 126, 70, 114, 100, 128, 130, 114, 160, 128, 190, 114, 220, 126]), 7, '#ffd23f');
    within(g, bun, () => fill(g, ellipse(128, 186, 120, 26), '#c97b3c'));
  } else if (k === 2) { // donut
    const d = circle(128, 128, 94); ink(g, d, '#e9b872', 10);
    const icing = blob([50, 120, 70, 60, 128, 40, 190, 58, 214, 118, 196, 176, 150, 170, 128, 200, 96, 170, 60, 180]); ink(g, icing, '#ff70a6', 8);
    ink(g, circle(128, 128, 30), '#15110e', 6); g.save(); g.globalCompositeOperation = 'destination-out'; fill(g, circle(128, 128, 24), '#000'); g.restore();
    const sprinkles = ['#ffffff', '#ffd23f', '#3a86ff', '#8ac926'];
    for (let i = 0; i < 18; i++) { const a = i * 2.4; const r = 50 + (i % 3) * 12; g.save(); g.translate(128 + Math.cos(a) * r, 128 + Math.sin(a) * r); g.rotate(a); fill(g, rrect(-8, -3, 16, 6, 3), sprinkles[i % 4]); g.restore(); }
  } else if (k === 3) { // cookie box
    const box = rrect(36, 50, 184, 160, 14); ink(g, box, '#3a86ff', 10);
    within(g, box, () => { fill(g, rrect(36, 50, 184, 40, 0), '#ffd23f'); fill(g, ellipse(50, 140, 30, 90), nightShade('#3a86ff')); });
    ink(g, circle(128, 150, 44), '#c68642', 7); for (const [x, y] of [[110, 136], [140, 160], [126, 172], [146, 134]]) fill(g, circle(x, y, 7), '#4a2c16');
    letter(g, 'COOKIES', 128, 72, 30, '#e63946', { align: 'center', outline: 5, shadow: false });
  } else { // sandwich
    const bread = blob([24, 170, 40, 80, 128, 40, 216, 80, 232, 170, 128, 200]); ink(g, bread, '#f6d7a7', 10);
    line(g, curve([34, 150, 128, 120, 222, 150]), 12, '#70e000'); line(g, curve([34, 164, 128, 136, 222, 164]), 10, '#e63946');
    within(g, bread, () => fill(g, ellipse(128, 40, 120, 24), '#c68642'));
  }
  t = tex(c); snackCache.set(k, t); return t;
}

export function buildSnackSprite(seed: number, size = 0.36): Sprite {
  const m = new SpriteMaterial({ map: snackTexture(seed), alphaTest: 0.5, toneMapped: false });
  const s = new Sprite(m); s.scale.set(size, size, 1); return s;
}

// ---------- net ----------
let netTex: CanvasTexture | null = null;
export function buildNet(): Sprite {
  if (!netTex) {
    const [c, g] = canvas(256, 256);
    const rim = circle(128, 128, 108);
    within(g, rim, () => { for (let k = -260; k < 260; k += 26) { line(g, curve([128 + k - 140, -10, 128 + k + 140, 266]), 5, '#e9edf2'); line(g, curve([128 + k + 140, -10, 128 + k - 140, 266]), 5, '#e9edf2'); } });
    g.lineWidth = 14; g.strokeStyle = INK; g.stroke(rim); g.lineWidth = 8; g.strokeStyle = '#8d99ae'; g.stroke(rim);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2; ink(g, circle(128 + Math.cos(a) * 108, 128 + Math.sin(a) * 108, 11), '#5c677d', 5); }
    netTex = tex(c);
  }
  const s = new Sprite(new SpriteMaterial({ map: netTex, alphaTest: 0.4, toneMapped: false })); s.scale.set(1.1, 1.1, 1); s.name = 'Net';
  return s;
}

// ---------- glows ----------
const glowCache = new Map<string, CanvasTexture>();
export function glowTexture(color: string): CanvasTexture {
  let t = glowCache.get(color); if (t) return t;
  const [c, g] = canvas(128, 128);
  const gr = g.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, color); gr.addColorStop(0.35, color + '88'); gr.addColorStop(1, color + '00');
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
  t = tex(c); glowCache.set(color, t); return t;
}
export function glow(color: string, size: number, opacity = 0.8): Sprite {
  const s = new Sprite(new SpriteMaterial({ map: glowTexture(color), blending: AdditiveBlending, depthWrite: false, transparent: true, opacity, toneMapped: false }));
  s.scale.set(size, size, 1); return s;
}

// ---------- raccoon paws (3D toon so they feel solid in your hands) ----------
let toonRamp: DataTexture | null = null;
function ramp(): DataTexture {
  if (!toonRamp) { toonRamp = new DataTexture(new Uint8Array([70, 160, 255]), 3, 1, RedFormat); toonRamp.minFilter = NearestFilter; toonRamp.magFilter = NearestFilter; toonRamp.needsUpdate = true; }
  return toonRamp;
}
const outlineMat = new MeshBasicMaterial({ color: INK, side: BackSide });
function toon(mesh: Mesh, color: string, outline = 1.12): Group {
  mesh.material = new MeshToonMaterial({ color, gradientMap: ramp() });
  const g = new Group(); g.add(mesh);
  const o = new Mesh(mesh.geometry, outlineMat); o.position.copy(mesh.position); o.rotation.copy(mesh.rotation); o.scale.copy(mesh.scale).multiplyScalar(outline); g.add(o);
  return g;
}
export function buildPaw(): Group {
  const g = new Group();
  const palm = new Mesh(new SphereGeometry(0.05, 14, 10)); palm.scale.set(1, 0.62, 1.25); g.add(toon(palm, '#8c9096'));
  for (let i = 0; i < 4; i++) {
    const f = new Mesh(new SphereGeometry(0.019, 10, 8)); f.position.set(-0.032 + i * 0.021, -0.002, -0.06); g.add(toon(f, '#8c9096', 1.18));
    const pad = new Mesh(new SphereGeometry(0.011, 8, 6), new MeshBasicMaterial({ color: '#2b2b2b' })); pad.position.set(-0.032 + i * 0.021, -0.014, -0.062); g.add(pad);
    const claw = new Mesh(new ConeGeometry(0.006, 0.022, 6), new MeshBasicMaterial({ color: '#f4f1de' })); claw.rotation.x = -Math.PI / 2; claw.position.set(-0.032 + i * 0.021, -0.002, -0.084); g.add(claw);
  }
  // striped raccoon cuff
  for (let k = 0; k < 2; k++) { const ring = new Mesh(new CylinderGeometry(0.044, 0.048, 0.026, 14)); ring.rotation.x = Math.PI / 2; ring.position.z = 0.045 + k * 0.027; g.add(toon(ring, k % 2 ? '#2f3136' : '#9a9ea5', 1.08)); }
  return g;
}

// ---------- comic bursts ----------
const burstCache = new Map<string, CanvasTexture>();
export function burstTexture(word: string, color = '#ffd23f', textColor = '#e63946'): CanvasTexture {
  const key = `${word}|${color}|${textColor}`; let t = burstCache.get(key); if (t) return t;
  const [c, g] = canvas(512, 384);
  const pts: number[] = []; const n = 18;
  for (let i = 0; i < n * 2; i++) { const a = i / (n * 2) * Math.PI * 2; const r = i % 2 ? 0.62 : 1; pts.push(256 + Math.cos(a) * 240 * r * (1 + ((i * 37) % 7) * 0.02), 192 + Math.sin(a) * 170 * r); }
  const b = poly(pts); ink(g, b, color, 12);
  halftone(g, b, 256, 192, 30, 360, shadeColor(color, -0.25), 16);
  g.save(); g.translate(256, 196); g.rotate(-0.08); letter(g, word, 0, 0, 132, textColor, { align: 'center', maxW: 400, outline: 18 }); g.restore();
  t = tex(c); burstCache.set(key, t); return t;
}

const numCache = new Map<string, CanvasTexture>();
export function numberTexture(text: string, color = '#ffd23f'): CanvasTexture {
  const key = text + color; let t = numCache.get(key); if (t) return t;
  const [c, g] = canvas(256, 128); letter(g, text, 128, 64, 84, color, { align: 'center', maxW: 236, outline: 12 });
  t = tex(c); numCache.set(key, t); return t;
}
export { COMIC_FONT };
