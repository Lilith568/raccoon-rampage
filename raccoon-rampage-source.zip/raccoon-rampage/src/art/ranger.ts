/** Ranger Rick, the boss: a hand-drawn paper puppet riding a cut-out jeep. */
import { AdditiveBlending, CanvasTexture, ConeGeometry, DoubleSide, Group, Mesh, MeshBasicMaterial, Object3D, Sprite } from '@iwsdk/core';
import { blob, canvas, card, circle, Ctx, curve, ellipse, fill, halftone, ink, INK, letter, line, nightShade, poly, rrect, shadeColor, Standee, tex, within } from './ink.js';
import { glow } from './props.js';

const OLIVE = '#6f8f3a'; const KHAKI = '#cdb27c'; const SKIN = '#f0b98c'; const HAT = '#b08850';

function drawJeepFront(g: Ctx): void {
  // body (side view, facing right)
  const body = poly([40, 250, 120, 236, 600, 236, 640, 210, 900, 214, 980, 250, 992, 330, 980, 380, 40, 380, 28, 320]);
  ink(g, body, OLIVE, 14);
  within(g, body, () => {
    fill(g, rrect(0, 330, 1024, 60, 0), shadeColor(OLIVE, -0.25));
    fill(g, ellipse(60, 300, 80, 140), nightShade(OLIVE));
    fill(g, rrect(130, 246, 760, 14, 6), shadeColor(OLIVE, 0.3));
  });
  halftone(g, body, 500, 330, 500, 390, shadeColor(OLIVE, -0.45), 16);
  // wheel arches (cut darker)
  for (const x of [250, 790]) { const a = ellipse(x, 384, 150, 120); within(g, body, () => fill(g, a, '#1d2412')); line(g, a, 10); }
  // door + star badge
  line(g, poly([380, 244, 600, 244, 600, 360, 380, 360]), 8);
  ink(g, rrect(560, 290, 30, 10, 4), '#c0c6d0', 5);
  const star: number[] = []; for (let k = 0; k < 10; k++) { const an = -Math.PI / 2 + k * Math.PI / 5; const r = k % 2 ? 26 : 56; star.push(470 + Math.cos(an) * r, 300 + Math.sin(an) * r); }
  ink(g, poly(star), '#ffd23f', 8);
  letter(g, 'PARK RANGER', 230, 300, 34, '#f4f1de', { align: 'center', outline: 6, shadow: false });
  // hood details, headlight, bumper
  line(g, curve([660, 222, 780, 230, 900, 222]), 6, shadeColor(OLIVE, -0.35));
  ink(g, circle(960, 262, 26), '#fff3b0', 8); fill(g, circle(966, 256, 9), '#ffffff');
  ink(g, rrect(950, 340, 70, 30, 10), '#9aa5b1', 8); ink(g, rrect(4, 340, 60, 30, 10), '#9aa5b1', 8);
  // windshield frame leaning back over the hood
  line(g, poly([640, 214, 600, 60, 618, 56, 660, 212], true), 10);
  ink(g, poly([604, 66, 618, 62, 652, 206, 640, 210]), '#9aa5b1', 4);
}

function drawJeepBack(g: Ctx): void {
  // roll bar with searchlight mount and a spare tyre at the back
  const bar = poly([150, 236, 170, 70, 430, 70, 450, 236, 420, 236, 404, 96, 196, 96, 180, 236]); ink(g, bar, '#3b4a22', 10);
  ink(g, circle(70, 250, 90), '#1d1d1d', 12); ink(g, circle(70, 250, 46), '#8d99ae', 8);
  ink(g, rrect(200, 150, 220, 100, 24), '#7a4e2d', 10); // seat back
  within(g, rrect(200, 150, 220, 100, 24), () => fill(g, rrect(200, 200, 220, 60, 0), '#5a3a22'));
}

function drawWheel(g: Ctx): void {
  ink(g, circle(128, 128, 112), '#232323', 12);
  within(g, circle(128, 128, 112), () => { for (let k = 0; k < 16; k++) { const a = k / 16 * Math.PI * 2; line(g, curve([128 + Math.cos(a) * 92, 128 + Math.sin(a) * 92, 128 + Math.cos(a + 0.12) * 116, 128 + Math.sin(a + 0.12) * 116]), 9, '#3d3d3d'); } });
  ink(g, circle(128, 128, 58), '#b8c0cc', 9); ink(g, circle(128, 128, 20), '#6c7683', 6);
  for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2; fill(g, circle(128 + Math.cos(a) * 38, 128 + Math.sin(a) * 38, 7), INK); }
}

function drawRickTorso(g: Ctx): void {
  const t = blob([60, 60, 200, 56, 240, 110, 246, 250, 20, 250, 22, 110]); ink(g, t, KHAKI, 11);
  within(g, t, () => { fill(g, ellipse(20, 160, 60, 140), nightShade(KHAKI)); fill(g, poly([128, 58, 150, 58, 160, 250, 118, 250]), '#3f5f2a'); });
  line(g, curve([110, 60, 140, 104, 170, 58]), 8);
  const star: number[] = []; for (let k = 0; k < 10; k++) { const an = -Math.PI / 2 + k * Math.PI / 5; const r = k % 2 ? 12 : 26; star.push(196 + Math.cos(an) * r, 140 + Math.sin(an) * r); }
  ink(g, poly(star), '#ffd23f', 5);
  ink(g, rrect(60, 120, 50, 40, 6), shadeColor(KHAKI, -0.15), 5);
}

type RickFace = 'grumpy' | 'ouch' | 'angry';
function drawRickHead(g: Ctx, face: RickFace): void {
  const skin = face === 'angry' ? '#f0736a' : SKIN;
  const ear = ellipse(140, 300, 36, 50); ink(g, ear, skin, 9);
  const head = blob([240, 110, 360, 110, 440, 170, 470, 270, 476, 370, 430, 450, 320, 480, 200, 460, 132, 400, 110, 290, 130, 170]);
  ink(g, head, skin, 12);
  within(g, head, () => { fill(g, ellipse(100, 320, 120, 220), nightShade(skin)); fill(g, ellipse(330, 150, 70, 22, -0.3), shadeColor(skin, 0.4)); });
  halftone(g, head, 240, 300, 80, 330, shadeColor(nightShade(skin), -0.2), 13);
  // stubble on the big chin
  within(g, head, () => { g.save(); g.globalAlpha = 0.35; fill(g, ellipse(360, 440, 140, 60), '#6d5a4a'); g.restore(); });
  // eyes
  if (face === 'ouch') {
    for (const [x, y, s] of [[340, 250, 40], [430, 246, 30]] as const) { line(g, curve([x - s, y - s, x, y, x + s, y + s]), 12); line(g, curve([x + s, y - s, x, y, x - s, y + s]), 12); }
  } else {
    for (const [x, y, rx, ry] of [[340, 256, 40, 34], [432, 252, 28, 30]] as const) {
      ink(g, ellipse(x, y, rx, ry), '#ffffff', 7); fill(g, circle(x + rx * 0.35, y + 4, rx * 0.42), INK);
      within(g, ellipse(x, y, rx, ry), () => fill(g, rrect(x - rx - 4, y - ry - 6, rx * 2 + 8, ry * (face === 'angry' ? 1.0 : 0.75), 0), skin));
      line(g, curve([x - rx, y - ry * 0.2, x, y - ry * 0.28, x + rx, y - ry * 0.2]), 6);
    }
    if (face === 'angry') for (const [x, y] of [[230, 140], [190, 180]] as const) { ink(g, blob([x, y, x - 30, y - 40, x + 10, y - 60, x + 30, y - 20]), '#ffffff', 6); }
  }
  // huge bushy brows (one unibrow-ish line)
  line(g, curve([286, face === 'angry' ? 196 : 206, 340, face === 'angry' ? 226 : 200, 396, 218]), 22, '#5a3a22');
  line(g, curve([404, 220, 436, face === 'angry' ? 230 : 204, 468, 214]), 18, '#5a3a22');
  // nose
  const nose = ellipse(478, 310, 44, 38, 0.2); ink(g, nose, face === 'angry' ? '#e8504a' : '#f4a27a', 9);
  // MOUSTACHE
  const st = blob([330, 360, 380, 330, 440, 340, 490, 330, 530, 366, 500, 380, 470, 372, 430, 392, 380, 384, 340, 400, 300, 392]);
  ink(g, st, '#5a3a22', 10); within(g, st, () => { for (let x = 310; x < 530; x += 18) line(g, curve([x, 350, x + 6, 370, x, 392]), 4, '#3b2416'); });
  // mouth
  if (face === 'ouch') ink(g, ellipse(410, 424, 34, 26), '#6b1d24', 7);
  else line(g, curve([370, 430, 410, face === 'angry' ? 410 : 418, 450, 430]), 9);
}

function drawHat(g: Ctx): void {
  const brim = ellipse(256, 150, 236, 34); ink(g, brim, shadeColor(HAT, -0.1), 11);
  const crown = poly([110, 146, 150, 40, 210, 20, 256, 44, 302, 20, 362, 40, 402, 146]); ink(g, crown, HAT, 11);
  within(g, crown, () => { fill(g, rrect(100, 110, 320, 36, 0), '#5a3a22'); fill(g, ellipse(130, 90, 50, 90), nightShade(HAT)); });
  line(g, curve([256, 46, 250, 90, 256, 112]), 6, shadeColor(HAT, -0.35));
  within(g, brim, () => fill(g, ellipse(256, 172, 236, 20), nightShade(HAT)));
}

function drawRickArm(g: Ctx): void {
  const sleeve = blob([28, 10, 100, 10, 106, 160, 92, 250, 36, 250, 22, 160]); ink(g, sleeve, KHAKI, 10);
  within(g, sleeve, () => fill(g, ellipse(24, 140, 26, 130), nightShade(KHAKI)));
  const hand = blob([32, 244, 98, 240, 112, 290, 90, 326, 44, 326, 24, 290]); ink(g, hand, SKIN, 9);
  ink(g, ellipse(108, 262, 14, 22, -0.4), SKIN, 7);
}

let T: Record<string, CanvasTexture> | null = null;
function textures(): Record<string, CanvasTexture> {
  if (T) return T;
  const mk = (w: number, h: number, f: (g: Ctx) => void) => { const [c, g] = canvas(w, h); f(g); return tex(c); };
  T = {
    jeepFront: mk(1024, 512, drawJeepFront), jeepBack: mk(512, 320, drawJeepBack), wheel: mk(256, 256, drawWheel),
    torso: mk(256, 256, drawRickTorso), grumpy: mk(560, 512, (g) => drawRickHead(g, 'grumpy')), ouch: mk(560, 512, (g) => drawRickHead(g, 'ouch')), angry: mk(560, 512, (g) => drawRickHead(g, 'angry')),
    hat: mk(512, 200, drawHat), arm: mk(128, 330, drawRickArm),
  };
  return T;
}

export interface RangerRig {
  root: Group; stand: Standee; flip: Group; jeep: Group; ranger: Group; hat: Mesh; armR: Object3D; light: Sprite; wheels: Object3D[]; beam: Mesh; lamp: Group;
  setFace(face: RickFace): void;
}

export function buildRanger(): RangerRig {
  const t = textures();
  const root = new Group(); root.name = 'RangerRick';
  const stand = new Standee(); root.add(stand);
  const flip = new Group(); stand.add(flip);
  const jeep = new Group(); flip.add(jeep);
  const back = card(t.jeepBack, 1.8, 1.12, 0.5, 0); back.position.set(-0.55, 0.95, -0.06); jeep.add(back);
  const ranger = new Group(); ranger.position.set(-0.35, 1.0, -0.03); jeep.add(ranger);
  const torso = card(t.torso, 0.8, 0.8, 0.5, 0); ranger.add(torso);
  const headJ = new Group(); headJ.position.set(0.06, 0.66, 0.01); ranger.add(headJ);
  const head = card(t.grumpy, 0.98, 0.9, 0.45, 0.06); headJ.add(head);
  const hat = card(t.hat, 1.1, 0.43, 0.5, 0.2); hat.position.set(0.02, 0.68, 0.02); hat.name = 'RangerHat'; headJ.add(hat);
  const armR = new Group(); armR.position.set(0.22, 0.62, 0.04); ranger.add(armR);
  armR.add(card(t.arm, 0.22, 0.6, 0.45, 0.96));
  const front = card(t.jeepFront, 3.6, 1.8, 0.5, 0); front.position.set(0, 0, 0); jeep.add(front);
  const wheels: Object3D[] = [];
  for (const x of [-1.15, 1.15]) { const w = card(t.wheel, 0.9, 0.9, 0.5, 0.5); w.position.set(x, 0.44, 0.02); jeep.add(w); wheels.push(w); }
  // searchlight on the roll bar
  const lamp = new Group(); lamp.position.set(-1.05, 2.02, -0.05); jeep.add(lamp);
  const [lc, lg] = canvas(160, 120); ink(lg, rrect(10, 20, 110, 80, 18), '#3b4a22', 8); ink(lg, ellipse(126, 60, 24, 46), '#fff3b0', 8); lamp.add(card(tex(lc), 0.5, 0.38, 0.4, 0.5));
  const light = glow('#fff3b0', 0.9, 0.7); light.position.set(0.25, 0, 0.05); lamp.add(light);
  const cone = new ConeGeometry(2.2, 16, 28, 1, true); cone.rotateX(-Math.PI / 2); cone.translate(0, 0, 8);
  const beam = new Mesh(cone, new MeshBasicMaterial({ color: '#fff6c8', transparent: true, opacity: 0.16, blending: AdditiveBlending, depthWrite: false, side: DoubleSide }));
  beam.visible = false; root.add(beam);
  const headMat = head.material as MeshBasicMaterial;
  return { root, stand, flip, jeep, ranger, hat, armR, light, wheels, beam, lamp, setFace: (f) => { headMat.map = t[f]; } };
}
