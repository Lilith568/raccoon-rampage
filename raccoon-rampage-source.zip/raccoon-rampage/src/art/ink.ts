/**
 * Comic "ink" toolkit: everything in Raccoon Rampage is drawn at runtime on canvases
 * (thick black outlines, flat colours, cel shadows, halftone dots) and shown on flat
 * cut-out cards, like a pop-up book standing around the player.
 */
import {
  CanvasTexture, DoubleSide, Group, Mesh, MeshBasicMaterial, PlaneGeometry, SRGBColorSpace, Sprite, SpriteMaterial, Texture,
} from '@iwsdk/core';

export const INK = '#15110e';
export type Ctx = CanvasRenderingContext2D;

export function canvas(w: number, h: number): [HTMLCanvasElement, Ctx] {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d')!; g.lineJoin = 'round'; g.lineCap = 'round';
  return [c, g];
}

export function tex(c: HTMLCanvasElement): CanvasTexture {
  const t = new CanvasTexture(c); t.colorSpace = SRGBColorSpace; t.anisotropy = 4; t.needsUpdate = true;
  return t;
}

/** Fills a path and gives it a thick outer ink line. */
export function ink(g: Ctx, p: Path2D, fill: string | CanvasGradient | CanvasPattern, lw = 10): void {
  g.save(); g.lineWidth = lw * 2; g.strokeStyle = INK; g.stroke(p); g.fillStyle = fill; g.fill(p); g.restore();
}

/** Fill only (no outline). */
export function fill(g: Ctx, p: Path2D, f: string | CanvasGradient): void { g.save(); g.fillStyle = f; g.fill(p); g.restore(); }

/** Inner ink line (for folds, creases, details). */
export function line(g: Ctx, p: Path2D, lw = 6, color = INK): void { g.save(); g.lineWidth = lw; g.strokeStyle = color; g.stroke(p); g.restore(); }

/** Draws `draw` clipped to `clip` (used for cel shadows and highlights inside a shape). */
export function within(g: Ctx, clip: Path2D, draw: () => void): void { g.save(); g.clip(clip); draw(); g.restore(); }

/** Halftone dots inside a clip, growing from one side: the classic printed-comic shadow. */
export function halftone(g: Ctx, clip: Path2D, x0: number, y0: number, x1: number, y1: number, color: string, step = 12, angle = 0.35): void {
  within(g, clip, () => {
    g.fillStyle = color;
    const dx = x1 - x0; const dy = y1 - y0; const len = Math.hypot(dx, dy) || 1;
    const minX = Math.min(x0, x1) - 200; const maxX = Math.max(x0, x1) + 200; const minY = Math.min(y0, y1) - 200; const maxY = Math.max(y0, y1) + 200;
    const ca = Math.cos(angle); const sa = Math.sin(angle);
    for (let u = -900; u < 900; u += step) for (let v = -900; v < 900; v += step) {
      const x = (minX + maxX) / 2 + u * ca - v * sa; const y = (minY + maxY) / 2 + u * sa + v * ca;
      if (x < minX || x > maxX || y < minY || y > maxY) continue;
      const k = ((x - x0) * dx + (y - y0) * dy) / (len * len); if (k <= 0) continue;
      const r = Math.min(1, k) * step * 0.48; if (r < 0.6) continue;
      g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
    }
  });
}

export function ellipse(cx: number, cy: number, rx: number, ry: number, rot = 0): Path2D { const p = new Path2D(); p.ellipse(cx, cy, rx, ry, rot, 0, Math.PI * 2); return p; }
export function circle(cx: number, cy: number, r: number): Path2D { return ellipse(cx, cy, r, r); }
export function rrect(x: number, y: number, w: number, h: number, r: number): Path2D { const p = new Path2D(); p.roundRect(x, y, w, h, r); return p; }
export function poly(pts: number[], close = true): Path2D {
  const p = new Path2D(); p.moveTo(pts[0], pts[1]);
  for (let i = 2; i < pts.length; i += 2) p.lineTo(pts[i], pts[i + 1]);
  if (close) p.closePath(); return p;
}
/** Smooth closed blob through points (Catmull-Rom → Bézier). */
export function blob(pts: number[], tension = 1): Path2D {
  const n = pts.length / 2; const p = new Path2D();
  const P = (i: number) => [pts[((i % n) + n) % n * 2], pts[((i % n) + n) % n * 2 + 1]];
  const [sx, sy] = P(0); p.moveTo(sx, sy);
  for (let i = 0; i < n; i++) {
    const [x0, y0] = P(i - 1); const [x1, y1] = P(i); const [x2, y2] = P(i + 1); const [x3, y3] = P(i + 2);
    p.bezierCurveTo(x1 + (x2 - x0) / 6 * tension, y1 + (y2 - y0) / 6 * tension, x2 - (x3 - x1) / 6 * tension, y2 - (y3 - y1) / 6 * tension, x2, y2);
  }
  p.closePath(); return p;
}
/** Open smooth stroke through points. */
export function curve(pts: number[]): Path2D {
  const p = new Path2D(); p.moveTo(pts[0], pts[1]);
  if (pts.length === 6) { p.quadraticCurveTo(pts[2], pts[3], pts[4], pts[5]); return p; }
  for (let i = 2; i < pts.length - 2; i += 2) { const mx = (pts[i] + pts[i + 2]) / 2; const my = (pts[i + 1] + pts[i + 3]) / 2; p.quadraticCurveTo(pts[i], pts[i + 1], mx, my); }
  p.lineTo(pts[pts.length - 2], pts[pts.length - 1]); return p;
}

/** Simple seeded RNG. */
export function rng(seed: number): () => number {
  let s = (seed * 2654435761) >>> 0 || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}

export function shadeColor(hex: string, k: number): string {
  const n = parseInt(hex.slice(1), 16); let r = (n >> 16) & 255; let gg = (n >> 8) & 255; let b = n & 255;
  if (k < 0) { r *= 1 + k; gg *= 1 + k; b *= 1 + k; } else { r += (255 - r) * k; gg += (255 - gg) * k; b += (255 - b) * k; }
  const h = (v: number) => Math.round(Math.max(0, Math.min(255, v))).toString(16).padStart(2, '0');
  return `#${h(r)}${h(gg)}${h(b)}`;
}
/** Cool night-time shadow tone for a colour (shadows go blue-violet in the comic palette). */
export function nightShade(hex: string): string { return mix(shadeColor(hex, -0.38), '#3b3d7a', 0.28); }
export function mix(a: string, b: string, k: number): string {
  const pa = parseInt(a.slice(1), 16); const pb = parseInt(b.slice(1), 16);
  const ch = (s: number) => Math.round(((pa >> s) & 255) * (1 - k) + ((pb >> s) & 255) * k).toString(16).padStart(2, '0');
  return `#${ch(16)}${ch(8)}${ch(0)}`;
}

// ---------- cards ----------
const geoCache = new Map<string, PlaneGeometry>();
/** Plane of size w×h whose origin sits at the anchor (ax, ay ∈ 0..1, 0 = left/bottom). */
export function cardGeo(w: number, h: number, ax = 0.5, ay = 0): PlaneGeometry {
  const key = `${w}|${h}|${ax}|${ay}`; let g = geoCache.get(key);
  if (!g) { g = new PlaneGeometry(w, h); g.translate((0.5 - ax) * w, (0.5 - ay) * h, 0); geoCache.set(key, g); }
  return g;
}

export function cutMat(map: Texture, tint = '#ffffff', fog = true): MeshBasicMaterial {
  const m = new MeshBasicMaterial({ map, color: tint, alphaTest: 0.5, side: DoubleSide, fog, toneMapped: false });
  m.alphaToCoverage = true;
  return m;
}

export function card(map: Texture, w: number, h: number, ax = 0.5, ay = 0, tint = '#ffffff'): Mesh {
  return new Mesh(cardGeo(w, h, ax, ay), cutMat(map, tint));
}

export function sprite(map: Texture, size: number, tint = '#ffffff', fog = true): Sprite {
  const m = new SpriteMaterial({ map, color: tint, alphaTest: 0.5, fog, toneMapped: false });
  const s = new Sprite(m); const img = map.image as HTMLCanvasElement;
  s.scale.set(size, size * (img.height / img.width), 1);
  return s;
}

/** Group that keeps facing the viewer around the vertical axis (paper puppets, standees). */
export class Standee extends Group {
  readonly isStandee = true;
}

// ---------- comic font ----------
export const COMIC_FONT = "'Bangers', 'Impact', 'Arial Black', system-ui, sans-serif";
/** Loads the bundled comic font before anything is drawn (falls back to Impact after 2.5 s). */
export function loadComicFont(url: string): Promise<void> {
  return new Promise((resolve) => {
    const done = () => resolve();
    const timer = setTimeout(done, 2500);
    try {
      const f = new FontFace('Bangers', `url(${url})`);
      f.load().then((ff) => { document.fonts.add(ff); clearTimeout(timer); done(); }).catch(() => { clearTimeout(timer); done(); });
    } catch { clearTimeout(timer); done(); }
  });
}

/** Comic lettering: heavy ink outline, coloured fill, little drop shadow. */
export function letter(g: Ctx, text: string, x: number, y: number, size: number, fillCol: string, opts: { align?: CanvasTextAlign; outline?: number; shadow?: boolean; maxW?: number } = {}): void {
  g.save();
  let s = size; g.font = `${s}px ${COMIC_FONT}`;
  if (opts.maxW) while (g.measureText(text).width > opts.maxW && s > 12) { s -= 2; g.font = `${s}px ${COMIC_FONT}`; }
  g.textAlign = opts.align ?? 'left'; g.textBaseline = 'middle';
  const ow = opts.outline ?? Math.max(4, s * 0.16);
  if (opts.shadow !== false) { g.lineWidth = ow; g.strokeStyle = INK; g.fillStyle = INK; g.strokeText(text, x + s * 0.06, y + s * 0.07); g.fillText(text, x + s * 0.06, y + s * 0.07); }
  g.lineWidth = ow; g.strokeStyle = INK; g.strokeText(text, x, y);
  g.fillStyle = fillCol; g.fillText(text, x, y);
  g.restore();
}
