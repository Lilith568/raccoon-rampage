/**
 * Comic campers as paper puppets: every body part is a hand-drawn card (drawn at runtime)
 * hinged at its joint, so the puppets can walk, wave snacks, flail and flee.
 */
import { AdditiveBlending, CanvasTexture, ConeGeometry, DoubleSide, Group, Mesh, MeshBasicMaterial, Object3D } from '@iwsdk/core';
import {
  mix, blob, canvas, card, circle, Ctx, curve, ellipse, halftone, ink, line, nightShade, poly, rng, shadeColor, tex, within, Standee, rrect, INK, fill,
} from './ink.js';
import { snackTexture } from './props.js';

const SKINS = ['#f6c89f', '#e8ad7f', '#c98a5a', '#8d5a3b', '#ffd9b8', '#b9784f'];
const SHIRTS = ['#ff4d4d', '#ff9f1c', '#2ec4b6', '#3a86ff', '#8ac926', '#ff70a6', '#9b5de5', '#ffd23f'];
const PANTS = ['#3d5a99', '#c2a878', '#2b2d42', '#4f772d', '#7a4e2d'];
const HAIRS = ['#1d1a1a', '#6b3f22', '#f1c45b', '#d9622b', '#b7b7b7', '#3b2416'];
type HairKind = 'messy' | 'cap' | 'beanie' | 'beard' | 'bun' | 'afro' | 'bowl' | 'pigtails';
type Pattern = 'plain' | 'stripes' | 'hawaii' | 'star' | 'plaid';

interface Look { skin: string; shirt: string; pants: string; hair: string; hairKind: HairKind; hat: string; pattern: Pattern; glasses: boolean; belly: boolean; shorts: boolean; kid: boolean; }

function makeLook(i: number, kid: boolean): Look {
  const r = rng(i * 97 + (kid ? 5000 : 11));
  const pick = <T,>(a: T[]) => a[Math.floor(r() * a.length)];
  const adultHair: HairKind[] = ['messy', 'cap', 'beanie', 'beard', 'bun', 'afro'];
  const kidHair: HairKind[] = ['bowl', 'pigtails', 'cap', 'messy'];
  const hairKind = kid ? kidHair[i % kidHair.length] : adultHair[i % adultHair.length];
  return {
    skin: SKINS[(i * 3 + (kid ? 1 : 0)) % SKINS.length], shirt: SHIRTS[(i * 5 + (kid ? 3 : 0)) % SHIRTS.length], pants: pick(PANTS), hair: hairKind === 'beard' ? pick(['#6b3f22', '#d9622b', '#b7b7b7']) : pick(HAIRS),
    hairKind, hat: pick(['#e63946', '#2a9d8f', '#ffb703', '#3a86ff', '#ffffff']), pattern: (['plain', 'stripes', 'hawaii', 'star', 'plaid'] as Pattern[])[(i * 7) % 5],
    glasses: !kid && r() < 0.3, belly: !kid && r() < 0.45, shorts: r() < (kid ? 0.7 : 0.4), kid,
  };
}

// ---------- head ----------
const HEAD = [250, 92, 360, 102, 432, 168, 458, 258, 446, 352, 398, 422, 306, 456, 208, 446, 140, 396, 104, 300, 118, 188, 168, 118];

function drawHead(g: Ctx, L: Look, expr: 'happy' | 'shock'): void {
  const shock = expr === 'shock';
  const skinSh = mix(shadeColor(L.skin, -0.2), '#6a5f9a', 0.18);
  // hair behind the head
  if (L.hairKind === 'afro') ink(g, blob([110, 230, 150, 110, 260, 50, 380, 70, 450, 150, 450, 240, 300, 220, 160, 330]), L.hair, 11);
  if (L.hairKind === 'bun') ink(g, circle(200, 70, 58), L.hair, 10);
  if (L.hairKind === 'pigtails') { ink(g, blob([90, 230, 40, 300, 60, 380, 120, 350, 140, 270]), L.hair, 10); }
  // ear
  const ear = ellipse(150, 300, 36, 48, -0.2); ink(g, ear, L.skin, 9); line(g, curve([140, 280, 160, 300, 142, 322]), 6, shadeColor(skinSh, -0.2));
  // face shape with cel shadow on the back of the head and a highlight on the forehead
  const head = blob(HEAD);
  ink(g, head, L.skin, 11);
  within(g, head, () => {
    fill(g, ellipse(70, 320, 100, 230), skinSh);
    fill(g, ellipse(300, 540, 230, 100), skinSh);
    fill(g, ellipse(330, 150, 70, 26, -0.35), shadeColor(L.skin, 0.4));
  });
  halftone(g, head, 190, 300, 40, 330, shadeColor(skinSh, -0.12), 13);
  // beard
  if (L.hairKind === 'beard') {
    const b = blob([170, 380, 230, 330, 330, 360, 420, 340, 470, 330, 460, 410, 400, 470, 300, 500, 200, 470]);
    ink(g, b, L.hair, 9);
    within(g, b, () => fill(g, ellipse(200, 470, 120, 60), nightShade(L.hair)));
  }
  // cheeks
  g.save(); g.globalAlpha = shock ? 0.25 : 0.5; fill(g, ellipse(352, 352, 40, 22), '#ff7b93'); g.restore();
  // eyes: big cartoon eyes looking forward (to the right)
  const eyes: [number, number, number, number][] = shock ? [[426, 232, 36, 52], [332, 236, 50, 64]] : [[426, 244, 30, 44], [334, 246, 42, 54]];
  for (const [x, y, rx, ry] of eyes) {
    ink(g, ellipse(x, y, rx, ry), '#ffffff', 7);
    if (shock) { fill(g, circle(x + 2, y, rx * 0.22), INK); }
    else { fill(g, ellipse(x + rx * 0.38, y + 4, rx * 0.46, ry * 0.46), INK); fill(g, circle(x + rx * 0.5, y - ry * 0.12, rx * 0.15), '#ffffff'); }
  }
  // brows
  const by = shock ? -40 : 0;
  line(g, curve([292, 186 + by, 334, 166 + by * 1.3, 376, 182 + by]), 13, L.hairKind === 'beard' || L.hairKind === 'cap' || L.hairKind === 'beanie' ? shadeColor(L.hair, -0.2) : shadeColor(L.hair, -0.25));
  line(g, curve([402, 184 + by, 430, 172 + by * 1.3, 456, 186 + by]), 11, shadeColor(L.hair, -0.25));
  // glasses
  if (L.glasses) { line(g, ellipse(eyes[1][0], eyes[1][1], 52, 56), 7, INK); line(g, ellipse(eyes[0][0], eyes[0][1], 38, 50), 7, INK); line(g, curve([384, 240, 392, 232, 398, 238]), 7); }
  // nose: a big round cartoon nose poking out of the profile
  const nose = ellipse(468, 300, 40, 34, 0.2); ink(g, nose, L.skin, 9);
  within(g, nose, () => { fill(g, ellipse(452, 322, 36, 18), skinSh); fill(g, ellipse(476, 286, 12, 8), shadeColor(L.skin, 0.5)); });
  // mouth
  if (shock) {
    const m = ellipse(396, 402, 30, 40, 0.1); ink(g, m, '#6b1d24', 8);
    within(g, m, () => { fill(g, ellipse(400, 440, 26, 16), '#ff7b93'); fill(g, rrect(368, 362, 60, 16, 6), '#ffffff'); });
    // sweat drops
    for (const [x, y, s] of [[262, 150, 1], [230, 196, 0.7]] as const) ink(g, blob([x, y - 26 * s, x + 14 * s, y, x, y + 14 * s, x - 14 * s, y]), '#8fd3ff', 5);
  } else {
    line(g, curve([352, 372, 402, 418, 446, 370]), 10);
    line(g, curve([346, 364, 352, 372, 346, 382]), 7);
  }
  // hair / hats in front
  const hk = L.hairKind;
  if (hk === 'messy') {
    const h = blob([108, 250, 104, 160, 150, 92, 210, 40, 260, 76, 300, 22, 340, 84, 400, 52, 410, 118, 460, 128, 430, 176, 360, 150, 300, 168, 230, 150, 176, 196, 150, 268]);
    ink(g, h, L.hair, 11); within(g, h, () => fill(g, ellipse(150, 230, 90, 120), nightShade(L.hair))); line(g, curve([230, 100, 260, 120, 300, 108]), 5, shadeColor(L.hair, 0.3));
  } else if (hk === 'cap') {
    const dome = blob([112, 228, 130, 140, 200, 86, 300, 76, 380, 100, 424, 150, 430, 196, 300, 176, 180, 196]);
    ink(g, dome, L.hat, 11); within(g, dome, () => { fill(g, ellipse(150, 200, 90, 100), nightShade(L.hat)); fill(g, ellipse(320, 110, 60, 18, -0.2), shadeColor(L.hat, 0.45)); });
    const brim = blob([400, 176, 470, 168, 520, 186, 500, 206, 420, 204]); ink(g, brim, shadeColor(L.hat, -0.15), 9);
    ink(g, circle(288, 80, 14), shadeColor(L.hat, -0.2), 6);
    line(g, curve([290, 92, 300, 140, 296, 182]), 5, shadeColor(L.hat, -0.35));
  } else if (hk === 'beanie') {
    const b = blob([110, 236, 116, 140, 190, 70, 300, 60, 400, 92, 440, 170, 446, 222, 300, 200, 180, 216]);
    ink(g, b, L.hat, 11); within(g, b, () => { for (let x = 120; x < 460; x += 28) line(g, curve([x, 60, x - 6, 140, x, 230]), 6, shadeColor(L.hat, -0.2)); fill(g, ellipse(150, 220, 80, 110), nightShade(L.hat)); });
    const band = blob([104, 236, 112, 196, 300, 176, 448, 198, 452, 238, 300, 222]); ink(g, band, shadeColor(L.hat, -0.12), 9);
    ink(g, circle(282, 46, 40), '#ffffff', 9); halftone(g, circle(282, 46, 40), 300, 30, 250, 80, '#cfd6e6', 10);
  } else if (hk === 'beard') {
    const top = blob([118, 250, 120, 170, 170, 112, 250, 90, 320, 98, 300, 120, 220, 130, 170, 180, 150, 260]); ink(g, top, L.hair, 9);
  } else if (hk === 'bun') {
    const h = blob([108, 260, 110, 170, 170, 104, 260, 86, 360, 96, 430, 150, 440, 190, 360, 160, 280, 150, 200, 176, 160, 240]);
    ink(g, h, L.hair, 11); within(g, h, () => fill(g, ellipse(150, 230, 80, 110), nightShade(L.hair)));
  } else if (hk === 'afro') {
    const f = blob([150, 170, 210, 110, 300, 96, 400, 120, 440, 170, 380, 160, 300, 150, 210, 170]); ink(g, f, L.hair, 9);
  } else if (hk === 'bowl') {
    const h = blob([104, 280, 106, 170, 170, 96, 280, 80, 380, 100, 440, 160, 452, 210, 380, 196, 300, 200, 220, 196, 160, 220, 150, 290]);
    ink(g, h, L.hair, 11); within(g, h, () => fill(g, ellipse(140, 240, 80, 110), nightShade(L.hair))); line(g, curve([330, 120, 360, 150, 372, 196]), 5, shadeColor(L.hair, 0.3));
  } else if (hk === 'pigtails') {
    const h = blob([110, 270, 112, 170, 180, 100, 290, 86, 390, 110, 440, 170, 446, 204, 360, 176, 260, 172, 180, 200, 150, 270]);
    ink(g, h, L.hair, 11); ink(g, circle(116, 252, 16), '#ff4d6d', 6);
  }
}

// ---------- torso, arms, legs ----------
function drawTorso(g: Ctx, L: Look): void {
  const belly = L.belly ? 26 : 0;
  const p = blob([72, 40, 184, 40, 222, 86, 232 + belly * 0.4, 190, 238 + belly, 280, 206 + belly * 0.5, 332, 62, 332, 32, 280, 30, 150, 40, 84]);
  ink(g, p, L.shirt, 11);
  within(g, p, () => {
    if (L.pattern === 'stripes') for (let y = 70; y < 340; y += 44) fill(g, rrect(0, y, 300, 18, 4), shadeColor(L.shirt, 0.55));
    if (L.pattern === 'plaid') { for (let y = 60; y < 340; y += 50) fill(g, rrect(0, y, 300, 14, 2), shadeColor(L.shirt, -0.3)); for (let x = 30; x < 260; x += 50) fill(g, rrect(x, 0, 12, 360, 2), shadeColor(L.shirt, -0.3)); }
    if (L.pattern === 'hawaii') for (const [x, y] of [[90, 110], [180, 160], [120, 240], [200, 270], [70, 300]]) { for (let k = 0; k < 5; k++) { const a = k / 5 * Math.PI * 2; fill(g, ellipse(x + Math.cos(a) * 14, y + Math.sin(a) * 14, 12, 8, a), '#fff3b0'); } fill(g, circle(x, y, 7), '#ff9f1c'); }
    if (L.pattern === 'star') { const s: number[] = []; for (let k = 0; k < 10; k++) { const a = -Math.PI / 2 + k * Math.PI / 5; const r = k % 2 ? 22 : 50; s.push(170 + Math.cos(a) * r, 170 + Math.sin(a) * r); } ink(g, poly(s), '#fff3b0', 6); }
    fill(g, ellipse(40, 200, 70, 190), nightShade(L.shirt));
    fill(g, ellipse(180, 80, 50, 16, -0.2), shadeColor(L.shirt, 0.35));
    // waistband / pants top
    fill(g, rrect(0, 296, 300, 60, 0), L.pants); line(g, curve([20, 300, 130, 306, 250, 298]), 7);
  });
  halftone(g, p, 150, 200, 20, 220, shadeColor(nightShade(L.shirt), -0.2), 12);
  // collar
  line(g, curve([150, 44, 176, 86, 196, 46]), 8);
  if (L.belly) line(g, curve([232, 250, 214, 262, 230, 276]), 5);
}

function drawArm(g: Ctx, L: Look): void {
  const longSleeve = L.pattern === 'plaid';
  const skin = L.skin;
  const fore = blob([46, 90, 82, 90, 90, 200, 86, 262, 42, 262, 38, 200]); ink(g, fore, longSleeve ? L.shirt : skin, 9);
  within(g, fore, () => fill(g, ellipse(40, 190, 22, 120), nightShade(longSleeve ? L.shirt : skin)));
  const hand = blob([36, 256, 94, 252, 104, 290, 86, 324, 48, 324, 30, 292]); ink(g, hand, skin, 9);
  ink(g, ellipse(100, 272, 13, 20, -0.4), skin, 7); // thumb
  within(g, hand, () => fill(g, ellipse(38, 300, 18, 30), nightShade(skin)));
  const sleeve = blob([30, 14, 98, 14, 108, 70, 100, 120, 28, 120, 20, 70]); ink(g, sleeve, L.shirt, 10);
  within(g, sleeve, () => { fill(g, ellipse(24, 70, 26, 70), nightShade(L.shirt)); if (L.pattern === 'stripes') fill(g, rrect(0, 60, 128, 18, 3), shadeColor(L.shirt, 0.55)); });
}

function drawLeg(g: Ctx, L: Look): void {
  const pantsEnd = L.shorts ? 150 : 292;
  if (L.shorts) {
    const shin = blob([42, 140, 86, 140, 84, 292, 44, 292]); ink(g, shin, L.skin, 9); within(g, shin, () => fill(g, ellipse(40, 220, 18, 90), nightShade(L.skin)));
    ink(g, rrect(40, 250, 48, 40, 8), '#ffffff', 7); // socks
  }
  const pant = blob([22, 6, 106, 6, 104, 80, 96, pantsEnd, 34, pantsEnd, 26, 80]); ink(g, pant, L.pants, 10);
  within(g, pant, () => { fill(g, ellipse(28, 150, 26, 170), nightShade(L.pants)); line(g, curve([80, 30, 76, 120, 80, pantsEnd - 10]), 4, shadeColor(L.pants, 0.25)); });
  const shoe = blob([24, 286, 92, 282, 126, 314, 122, 344, 22, 344, 14, 316]); ink(g, shoe, L.kid ? '#ff4d6d' : '#3a2b22', 9);
  within(g, shoe, () => { fill(g, rrect(0, 330, 140, 30, 0), '#f4f1de'); fill(g, ellipse(96, 300, 18, 8), '#ffffff40'); });
}

function drawTorch(): CanvasTexture {
  const [c, g] = canvas(160, 96);
  const body = rrect(14, 30, 100, 36, 14); ink(g, body, '#ffd23f', 7);
  within(g, body, () => fill(g, rrect(14, 52, 100, 20, 0), '#e0a800'));
  const head = poly([108, 18, 146, 8, 146, 88, 108, 78]); ink(g, head, '#9aa5b1', 7); fill(g, rrect(138, 14, 8, 68, 3), '#fff7c2');
  return tex(c);
}

interface LookTex { head: CanvasTexture; shock: CanvasTexture; torso: CanvasTexture; arm: CanvasTexture; leg: CanvasTexture; }
const lookCache = new Map<string, LookTex>();
function lookTex(i: number, kid: boolean): LookTex {
  const key = `${kid ? 'k' : 'a'}${i}`; let t = lookCache.get(key);
  if (t) return t;
  const L = makeLook(i, kid);
  const [hc, hg] = canvas(512, 512); drawHead(hg, L, 'happy');
  const [sc, sg] = canvas(512, 512); drawHead(sg, L, 'shock');
  const [tc, tg] = canvas(256, 340); drawTorso(tg, L);
  const [ac, ag] = canvas(128, 330); drawArm(ag, L);
  const [lc, lg] = canvas(128, 350); drawLeg(lg, L);
  t = { head: tex(hc), shock: tex(sc), torso: tex(tc), arm: tex(ac), leg: tex(lc) };
  lookCache.set(key, t); return t;
}
let torchTex: CanvasTexture | null = null;

export interface CamperRig {
  root: Group; stand: Standee; flip: Group; body: Group;
  head: Mesh; armL: Object3D; armR: Object3D; legL: Object3D; legR: Object3D; snackHolder: Group;
  flashlight: Group | null; beam: Mesh | null; height: number;
  setFace(shock: boolean): void;
}

const BACK = '#b9bfdc';
export function buildCamper(seed: number, opts: { kid?: boolean; flashlight?: boolean } = {}): CamperRig {
  const kid = !!opts.kid;
  const T = lookTex(seed % (kid ? 4 : 8), kid);
  const root = new Group(); const stand = new Standee(); root.add(stand);
  const flip = new Group(); stand.add(flip);
  const body = new Group(); flip.add(body); if (kid) body.scale.setScalar(0.64);
  const joint = (x: number, y: number, z: number) => { const j = new Group(); j.position.set(x, y, z); body.add(j); return j; };
  const legL = joint(-0.07, 0.9, -0.012); legL.add(card(T.leg, 0.26, 0.92, 0.42, 1, BACK));
  const legR = joint(0.07, 0.9, 0.012); legR.add(card(T.leg, 0.26, 0.92, 0.42, 1));
  const torso = card(T.torso, 0.62, 0.82, 0.5, 0); torso.position.set(0, 0.74, 0); body.add(torso);
  const armL = joint(-0.03, 1.46, -0.03); armL.add(card(T.arm, 0.2, 0.66, 0.4, 0.96, BACK));
  const headJ = joint(0.04, 1.42, 0.02); if (kid) headJ.scale.setScalar(1.22);
  const headMat = card(T.head, 0.72, 0.72, 0.5, 0.11); headJ.add(headMat);
  const armR = joint(0.05, 1.46, 0.045); armR.add(card(T.arm, 0.2, 0.66, 0.4, 0.96));
  const snackHolder = new Group(); snackHolder.position.set(0.1, kid ? 1.98 : 2.0, 0.06); body.add(snackHolder);
  let flashlight: Group | null = null; let beam: Mesh | null = null;
  if (opts.flashlight) {
    torchTex ??= drawTorch();
    flashlight = new Group(); const t = card(torchTex, 0.3, 0.18, 0.15, 0.5); t.rotation.z = -Math.PI / 2; t.position.set(0, -0.6, 0.01); flashlight.add(t);
    armR.add(flashlight);
    // the light cone lives in world orientation and is aimed by the game
    const cone = new ConeGeometry(1.5, 9, 24, 1, true); cone.rotateX(-Math.PI / 2); cone.translate(0, 0, 4.5);
    beam = new Mesh(cone, new MeshBasicMaterial({ color: '#fff3b0', transparent: true, opacity: 0.2, blending: AdditiveBlending, depthWrite: false, side: DoubleSide }));
    beam.visible = false; root.add(beam);
  }
  const rig: CamperRig = {
    root, stand, flip, body, head: headMat, armL, armR, legL, legR, snackHolder, flashlight, beam, height: kid ? 1.35 : 1.9,
    setFace: (shock) => { (headMat.material as MeshBasicMaterial).map = shock ? T.shock : T.head; },
  };
  return rig;
}

/** Snack that the camper proudly holds above their head (a card in the puppet plane). */
export function heldSnack(seed: number): Mesh {
  const t = snackTexture(seed);
  const m = card(t, 0.42, 0.42, 0.5, 0.2); m.name = 'snack';
  return m;
}
